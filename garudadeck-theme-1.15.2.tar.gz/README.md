# GarudaDeck Theme
<p align="center"><img src="garudadeck-logo.png" width="180" alt="GarudaDeck logo by verlangid"></p>
Open source Pterodactyl theme by **verlangid** from Indonesia. License MIT.
Custom domain per server with real DNS check plus global announcements, clean UI, one line install.
Support panel 1.11 to 1.15, Ubuntu 20.04, 22.04, 24.04, Debian 11, 12, PHP 8.2, 8.3.
Logo GarudaDeck otomatis terpasang ke halaman login, favicon browser, dan tab website saat install.
## Install satu perintah, auto sudo
Jalan sebagai user biasa maupun root, tanpa pusing sudo dan tanpa process substitution:
curl -fsSL https://raw.githubusercontent.com/Verlangid11/garudadeck-theme/main/install.sh | bash
## Aksi lain
Cek saja:
curl -fsSL https://raw.githubusercontent.com/Verlangid11/garudadeck-theme/main/install.sh | bash -s -- check
Backup saja:
curl -fsSL https://raw.githubusercontent.com/Verlangid11/garudadeck-theme/main/install.sh | bash -s -- backup
Rollback:
curl -fsSL https://raw.githubusercontent.com/Verlangid11/garudadeck-theme/main/install.sh | bash -s -- rollback
Panel beda path:
curl -fsSL https://raw.githubusercontent.com/Verlangid11/garudadeck-theme/main/install.sh | PANEL_DIR=/var/www/panel bash -s -- install
## Kenapa kompatibel
- Tanpa bash process substitution, jadi aman di semua sudo dan shell.
- Auto sudo dengan sudo -E bila jalan sebagai user biasa.
- Deteksi OS Ubuntu 20.04, 22.04, 24.04, Debian 11, 12.
- Tolak panel di luar 1.11 sampai 1.15 sebelum ubah apa pun.
- Backup kode plus DB dulu, baru pasang file.
- Patch idempoten, aman jalan ulang.
## Branding included
- public/garudadeck-logo.png for login and website header
- public/favicons full set generated from GarudaDeck logo
- resources/scripts/components/elements/GarudaLogo.tsx reusable logo component
- Login page brand mark replaced with GarudaDeck logo
- Rollback removes logo and restores original favicons from backup
