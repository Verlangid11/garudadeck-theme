#!/bin/bash
# GarudaDeck by verlangid, open source MIT dari Indonesia.
# Satu perintah, auto sudo bila bukan root:
# curl -fsSL https://raw.githubusercontent.com/Verlangid11/garudadeck-theme/main/install.sh | bash
# Aksi: tambah -s -- check | backup | rollback, contoh:
# curl -fsSL .../install.sh | bash -s -- check
set -euo pipefail
if [ "$(id -u)" != "0" ]; then
  if command -v sudo >/dev/null 2>&1; then
    echo "[garudadeck] bukan root, naik ke sudo otomatis"
    exec sudo -E bash "$0" "$@"
  else
    echo "[garudadeck] ERROR: jalankan sebagai root atau install sudo dulu" >&2
    exit 1
  fi
fi
THEME_REPO="${THEME_REPO:-Verlangid11/garudadeck-theme}"
THEME_BRANCH="${THEME_BRANCH:-main}"
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
ACTION="${1:-install}"
TMP_DIR="$(mktemp -d)"
cleanup() { rm -rf "$TMP_DIR"; }
trap cleanup EXIT
log() { echo "[garudadeck] $1"; }
fail() { echo "[garudadeck] ERROR: $1" >&2; exit 1; }
need() { command -v "$1" >/dev/null 2>&1 || fail "$1 belum terpasang, install dulu: apt install $1"; }
need curl
need tar
case "$ACTION" in install|check|backup|rollback) ;; *) fail "aksi tidak dikenal: $ACTION. Pakai install, check, backup, atau rollback" ;; esac
TARBALL_URL="https://github.com/${THEME_REPO}/releases/latest/download/garudadeck-theme-1.15.2.tar.gz"
RAW_DIR_URL="https://raw.githubusercontent.com/${THEME_REPO}/${THEME_BRANCH}"
ARCHIVE="$TMP_DIR/theme.tar.gz"
EXTRACT="$TMP_DIR/extract"
log "GarudaDeck by verlangid, repo $THEME_REPO, panel $PANEL_DIR, aksi $ACTION"
mkdir -p "$EXTRACT"
if curl -fsSL "$TARBALL_URL" -o "$ARCHIVE"; then
  log "unduh dari release stabil"
  tar -xzf "$ARCHIVE" -C "$EXTRACT" || fail "arsip release rusak"
else
  log "release belum ada, unduh file langsung dari branch $THEME_BRANCH"
  rm -rf "$EXTRACT/theme-switcher"
  mkdir -p "$EXTRACT/theme-switcher/installer" "$EXTRACT/theme-switcher/backend"
  curl -fsSL "$RAW_DIR_URL/theme-switcher/install.sh" -o "$EXTRACT/theme-switcher/install.sh" || fail "gagal unduh installer"
  for f in installer/check.sh installer/backup.sh installer/apply.sh installer/branding.sh installer/install.sh installer/rollback.sh backend/patch.sh; do
    mkdir -p "$EXTRACT/theme-switcher/$(dirname "$f")"
    curl -fsSL "$RAW_DIR_URL/theme-switcher/$f" -o "$EXTRACT/theme-switcher/$f" || fail "gagal unduh $f"
  done
  chmod +x "$EXTRACT/theme-switcher/install.sh" "$EXTRACT/theme-switcher/installer/"*.sh "$EXTRACT/theme-switcher/backend/patch.sh"
  log "unduh file inti selesai, mode ringan tanpa arsip penuh"
fi
SWITCHER="$EXTRACT/theme-switcher"
[ -f "$SWITCHER/install.sh" ] || fail "install.sh tidak ketemu di paket"
log "jalankan $ACTION"
PANEL_DIR="$PANEL_DIR" bash "$SWITCHER/install.sh" "$ACTION"
