#!/bin/bash
# GarudaDeck backup: kode plus database sebelum ubah apa pun. Tidak pernah gagal diam diam.
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
BACKUP_ROOT="${BACKUP_ROOT:-$PANEL_DIR/theme-backups}"
log() { echo "[garudadeck-backup] $1"; }
fail() { echo "[garudadeck-backup] ERROR: $1" >&2; exit 1; }
VER="$(grep -oP "'version' => '\K[^']+" "$PANEL_DIR/config/app.php" 2>/dev/null | head -1)"
VER="${VER:-unknown}"
STAMP="$(date -u +%Y%m%d-%H%M%S)"
NAME="pterodactyl-original-${VER}-${STAMP}"
mkdir -p "$BACKUP_ROOT" /tmp/opencode
ARCHIVE="/tmp/opencode/${NAME}.tar.gz"
[ -w /tmp/opencode ] || fail "/tmp/opencode tidak bisa ditulis"
[ -w "$BACKUP_ROOT" ] || fail "$BACKUP_ROOT tidak bisa ditulis, jalankan dengan sudo"
log "arsip kode ke $ARCHIVE"
tar --exclude='./node_modules' --exclude='./vendor' --exclude='./storage/logs/*' --exclude='./storage/framework/cache/*' --exclude='./storage/framework/sessions/*' --exclude='./storage/framework/views/*' --exclude='./theme-switcher' --exclude='./theme-backups' --exclude='./.git' -czf "$ARCHIVE" -C "$PANEL_DIR" . || fail "arsip gagal, batal sebelum ubah panel"
[ -s "$ARCHIVE" ] || fail "arsip kosong, batal"
mkdir -p "$BACKUP_ROOT/$NAME"
tar -xzf "$ARCHIVE" -C "$BACKUP_ROOT/$NAME" || fail "ekstrak backup gagal"
DB_FILE="$BACKUP_ROOT/$NAME/database.sql.gz"
DB_OK="no"
if [ -f "$PANEL_DIR/.env" ] && command -v mysqldump >/dev/null 2>&1 && command -v gzip >/dev/null 2>&1; then
  DB_HOST="$(grep -E '^DB_HOST=' "$PANEL_DIR/.env" | cut -d= -f2 | tr -d '"')"
  DB_PORT="$(grep -E '^DB_PORT=' "$PANEL_DIR/.env" | cut -d= -f2 | tr -d '"')"
  DB_NAME="$(grep -E '^DB_DATABASE=' "$PANEL_DIR/.env" | cut -d= -f2 | tr -d '"')"
  DB_USER="$(grep -E '^DB_USERNAME=' "$PANEL_DIR/.env" | cut -d= -f2 | tr -d '"')"
  DB_PASS="$(grep -E '^DB_PASSWORD=' "$PANEL_DIR/.env" | cut -d= -f2- | tr -d '"')"
  if [ -n "${DB_NAME:-}" ]; then
    if MYSQL_PWD="$DB_PASS" mysqldump -h "${DB_HOST:-127.0.0.1}" -P "${DB_PORT:-3306}" -u "$DB_USER" "$DB_NAME" 2>/dev/null | gzip > "$DB_FILE"; then
      [ -s "$DB_FILE" ] && DB_OK="yes" || log "dump DB kosong, lanjut tanpa DB"
    else
      log "dump DB gagal, lanjut tanpa DB"
      rm -f "$DB_FILE"
    fi
  fi
else
  log "mysqldump atau .env tidak ada, lewati backup DB"
fi
{ echo "name=$NAME"; echo "panel_version=$VER"; echo "created_utc=$STAMP"; echo "db_backup=$DB_OK"; echo "source=panel original sebelum GarudaDeck"; } > "$BACKUP_ROOT/$NAME/MANIFEST.txt"
cp "$ARCHIVE" "$BACKUP_ROOT/${NAME}.tar.gz" || fail "salin arsip ke backup gagal"
[ -s "$BACKUP_ROOT/${NAME}.tar.gz" ] || fail "arsip backup kosong"
log "selesai: $BACKUP_ROOT/$NAME, db=$DB_OK"
echo "$BACKUP_ROOT/$NAME"
