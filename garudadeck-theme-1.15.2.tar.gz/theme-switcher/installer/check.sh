#!/bin/bash
# GarudaDeck check: tolak OS, panel, PHP, tool wajib sebelum ubah apa pun.
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
MIN_PANEL="1.11.0"
MAX_PANEL="1.15.99"
SUPPORTED_OS="ubuntu-20.04 ubuntu-22.04 ubuntu-24.04 debian-11 debian-12"
SUPPORTED_PHP="8.2 8.3"
log() { echo "[garudadeck-check] $1"; }
fail() { echo "[garudadeck-check] ERROR: $1" >&2; exit 1; }
detect_os() { if [ -f /etc/os-release ]; then . /etc/os-release; echo "${ID}-${VERSION_ID}"; else echo unknown; fi; }
panel_version() { grep -oP "'version' => '\K[^']+" "$PANEL_DIR/config/app.php" 2>/dev/null | head -1; }
version_ok() { [ "$(printf '%s\n%s\n' "$MIN_PANEL" "$1" | sort -V | head -1)" = "$MIN_PANEL" ] && [ "$(printf '%s\n%s\n' "$1" "$MAX_PANEL" | sort -V | head -1)" = "$1" ]; }
need_warn() { command -v "$1" >/dev/null 2>&1 || echo "[garudadeck-check] peringatan: $1 tidak ada, $2"; }
OS_ID="$(detect_os)"
log "OS: $OS_ID"
case " $SUPPORTED_OS " in *" $OS_ID "*) log "OS didukung" ;; *) fail "OS $OS_ID belum didukung. Didukung: $SUPPORTED_OS" ;; esac
[ -d "$PANEL_DIR" ] || fail "panel tidak ketemu di $PANEL_DIR, set PANEL_DIR yang benar"
[ -f "$PANEL_DIR/config/app.php" ] || fail "config/app.php hilang, bukan panel Pterodactyl"
command -v php >/dev/null 2>&1 || fail "php tidak ketemu, install PHP 8.2 atau 8.3 dulu"
command -v tar >/dev/null 2>&1 || fail "tar tidak ketemu, apt install tar dulu"
command -v python3 >/dev/null 2>&1 || fail "python3 tidak ketemu, apt install python3 dulu"
command -v curl >/dev/null 2>&1 || fail "curl tidak ketemu, apt install curl dulu"
need_warn composer "composer hanya wajib bila vendor hilang"
need_warn rsync "rollback butuh rsync, nanti diinstall otomatis bila apt tersedia"
need_warn mysql "restore DB dilewati bila mysql tidak ada, kode tetap dirollback"
need_warn mysqldump "backup DB dilewati bila mysqldump tidak ada, kode tetap dibackup"
VER="$(panel_version)"
[ -n "$VER" ] || fail "versi panel tidak terbaca"
log "panel: $VER"
version_ok "$VER" || fail "panel $VER di luar $MIN_PANEL sampai $MAX_PANEL"
PHP_VER="$(php -r 'echo PHP_MAJOR_VERSION.".".PHP_MINOR_VERSION;' 2>/dev/null || echo none)"
log "PHP: $PHP_VER"
case " $SUPPORTED_PHP " in *" $PHP_VER "*) log "PHP didukung" ;; *) fail "PHP $PHP_VER tidak didukung. Butuh 8.2 atau 8.3" ;; esac
if command -v node >/dev/null 2>&1; then log "Node: $(node -v)"; else log "Node tidak ada, build frontend dilewati"; fi
if [ ! -w "$PANEL_DIR" ]; then fail "$PANEL_DIR tidak bisa ditulis, jalankan dengan sudo"; fi
if [ -f "$PANEL_DIR/.env" ]; then log ".env ketemu"; else log "peringatan: .env tidak ketemu, backup DB dilewati"; fi
log "cek lolos, lanjut backup"
