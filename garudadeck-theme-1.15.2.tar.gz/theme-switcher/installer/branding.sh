#!/bin/bash
# GarudaDeck branding: pasang logo ke public, favicon, dan patch login.
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PANEL_DIR" || exit 1
echo "[garudadeck-brand] pasang logo"
copy_force() { mkdir -p "$(dirname "$2")"; cp -f "$1" "$2"; echo "salin $2"; }
if [ -f "$HERE/frontend/public/garudadeck-logo.png" ]; then
  copy_force "$HERE/frontend/public/garudadeck-logo.png" public/garudadeck-logo.png
elif [ -f theme-switcher/frontend/public/garudadeck-logo.png ]; then
  copy_force theme-switcher/frontend/public/garudadeck-logo.png public/garudadeck-logo.png
fi
SRC_FAV="$HERE/frontend/public/favicons"
[ -d "$SRC_FAV" ] || SRC_FAV="theme-switcher/frontend/public/favicons"
if [ -d "$SRC_FAV" ]; then
  mkdir -p public/favicons
  cp -rf "$SRC_FAV"/. public/favicons/
  echo "favicon GarudaDeck dipasang ($(ls public/favicons | wc -l) file)"
else
  echo "sumber favicon tidak ketemu, lewati"
fi
SRC_LOGO="$HERE/frontend/scripts/components/elements/GarudaLogo.tsx"
[ -f "$SRC_LOGO" ] || SRC_LOGO="theme-switcher/frontend/scripts/components/elements/GarudaLogo.tsx"
if [ -f "$SRC_LOGO" ]; then
  mkdir -p resources/scripts/components/elements
  cp -f "$SRC_LOGO" resources/scripts/components/elements/GarudaLogo.tsx
  echo "komponen GarudaLogo dipasang"
fi
python3 - <<'PY'
import pathlib
p = pathlib.Path('resources/scripts/components/auth/LoginFormContainer.tsx')
if not p.exists():
    print('login form tidak ketemu, lewati patch logo')
    raise SystemExit(0)
s = p.read_text()
if 'GarudaLogo' in s:
    print('logo login sudah ada, lewati')
    raise SystemExit(0)
anchor = "import ThemeToggle from '@/components/elements/ThemeToggle';"
if anchor in s:
    s = s.replace(anchor, anchor + "\nimport GarudaLogo from '@/components/elements/GarudaLogo';")
    s = s.replace('<Mark>{appName.slice(0, 2).toUpperCase()}</Mark>', '<GarudaLogo size={36} />')
    p.write_text(s)
    print('logo login dipasang')
else:
    print('anchor login tidak ketemu, lewati')
PY
echo "[garudadeck-brand] selesai"
