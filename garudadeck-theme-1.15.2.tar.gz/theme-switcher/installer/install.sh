#!/bin/bash
# GarudaDeck installer inti: cek, backup, pasang, branding, migrasi, build, verifikasi.
# Aman: tiap tahap gagal langsung tawarkan rollback otomatis ke backup barusan.
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
BACKUP_ROOT="${BACKUP_ROOT:-$PANEL_DIR/theme-backups}"
AUTO_ROLLBACK="${AUTO_ROLLBACK:-1}"
HERE="$(cd "$(dirname "$0")" && pwd)"
log() { echo "[garudadeck-install] $1"; }
fail() { echo "[garudadeck-install] ERROR: $1" >&2; exit 1; }
BACKUP_DIR=""
auto_rollback() {
  [ "${AUTO_ROLLBACK}" = "1" ] || return 0
  [ -n "${BACKUP_DIR:-}" ] && [ -d "$BACKUP_DIR" ] || return 0
  log "gagal di tengah jalan, rollback otomatis ke $BACKUP_DIR"
  PANEL_DIR="$PANEL_DIR" BACKUP_ROOT="$BACKUP_ROOT" bash "$HERE/rollback.sh" --auto --target "$BACKUP_DIR" || log "rollback otomatis gagal, jalankan manual"
}
trap 'code=$?; [ $code -ne 0 ] && auto_rollback; exit $code' EXIT
need() { command -v "$1" >/dev/null 2>&1 || fail "$1 tidak ketemu, install dulu: apt install $1"; }
need php
need tar
need python3
bash "$HERE/check.sh" || fail "cek gagal, batal sebelum ubah apa pun"
BACKUP_DIR="$(bash "$HERE/backup.sh" | tail -1)"
log "backup aktif: $BACKUP_DIR"
[ -d "$BACKUP_DIR" ] || fail "backup tidak ketemu di $BACKUP_DIR"
cd "$PANEL_DIR" || fail "tidak bisa masuk $PANEL_DIR"
log "1/6 pasang file tema"
bash "$HERE/apply.sh" || fail "apply gagal"
log "2/6 pasang logo GarudaDeck"
bash "$HERE/branding.sh" || fail "branding gagal"
log "3/6 lengkapi vendor bila hilang"
if [ ! -d vendor ]; then
  need composer
  composer install --no-dev --optimize-autoloader || fail "composer gagal"
else
  log "vendor ada, lewati"
fi
log "4/6 migrasi database"
php artisan migrate --force || fail "migrasi gagal"
log "5/6 bersihkan cache dan build frontend"
php artisan view:clear >/dev/null 2>&1 || true
php artisan config:clear >/dev/null 2>&1 || true
php artisan route:clear >/dev/null 2>&1 || true
if command -v yarn >/dev/null 2>&1 && [ -f package.json ]; then
  if yarn build; then log "build yarn sukses"; else log "yarn gagal, lanjut, panel tetap jalan"; fi
else
  log "yarn tidak ada, lewati build"
fi
log "6/6 verifikasi"
php -l app/Models/Announcement.php >/dev/null || fail "syntax Announcement rusak"
php -l app/Models/ServerCustomDomain.php >/dev/null || fail "syntax ServerCustomDomain rusak"
[ -f public/garudadeck-logo.png ] || fail "logo tidak kepasang"
php artisan route:list --name=admin.announcements >/dev/null || fail "route pengumuman hilang"
trap - EXIT
log "selesai. Backup aman di $BACKUP_DIR."
log "Bila suatu saat error jalankan: curl .../install.sh | bash -s -- rollback"
