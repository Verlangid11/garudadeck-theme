#!/bin/bash
# GarudaDeck apply: salin file tema tanpa timpa, patch route idempoten.
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
HERE="$(cd "$(dirname "$0")/.." && pwd)"
cd "$PANEL_DIR" || exit 1
copy_new() {
  local src="$1" dest="$2"
  mkdir -p "$(dirname "$dest")"
  if [ ! -f "$dest" ]; then cp "$src" "$dest"; echo "salin $dest"; else echo "lewati $dest"; fi
}
copy_new "$HERE/backend/app/Models/Announcement.php" app/Models/Announcement.php
copy_new "$HERE/backend/app/Models/ServerCustomDomain.php" app/Models/ServerCustomDomain.php
copy_new "$HERE/backend/app/Services/Servers/ServerDomainVerificationService.php" app/Services/Servers/ServerDomainVerificationService.php
copy_new "$HERE/backend/app/Console/Commands/Domain/RecheckServerDomainsCommand.php" app/Console/Commands/Domain/RecheckServerDomainsCommand.php
copy_new "$HERE/backend/app/Http/Controllers/Api/Client/Servers/ServerDomainController.php" app/Http/Controllers/Api/Client/Servers/ServerDomainController.php
copy_new "$HERE/backend/app/Http/Controllers/Api/Client/AnnouncementController.php" app/Http/Controllers/Api/Client/AnnouncementController.php
copy_new "$HERE/backend/app/Http/Controllers/Admin/AnnouncementController.php" app/Http/Controllers/Admin/AnnouncementController.php
mkdir -p app/Http/Requests/Api/Client/Servers/Domain
copy_new "$HERE/backend/app/Http/Requests/Api/Client/Servers/Domain/GetDomainRequest.php" app/Http/Requests/Api/Client/Servers/Domain/GetDomainRequest.php
copy_new "$HERE/backend/app/Http/Requests/Api/Client/Servers/Domain/UpdateDomainRequest.php" app/Http/Requests/Api/Client/Servers/Domain/UpdateDomainRequest.php
mkdir -p database/migrations
for f in "$HERE"/backend/database/migrations/*.php; do copy_new "$f" "database/migrations/$(basename "$f")"; done
mkdir -p resources/views/admin/announcements resources/views/layouts
copy_new "$HERE/backend/resources/views/admin/announcements/index.blade.php" resources/views/admin/announcements/index.blade.php
if ! grep -q "admin.announcements" resources/views/layouts/admin.blade.php 2>/dev/null; then
  cp "$HERE/backend/resources/views/layouts/admin.blade.php" resources/views/layouts/admin.blade.php
  echo "sidebar admin dipasang"
else
  echo "sidebar admin sudah ada"
fi
mkdir -p resources/scripts/api/server resources/scripts/components/server/domain resources/scripts/components/elements resources/scripts/components/dashboard resources/scripts/components/server/console
copy_new "$HERE/frontend/scripts/api/server/domain.ts" resources/scripts/api/server/domain.ts
copy_new "$HERE/frontend/scripts/api/getAnnouncement.ts" resources/scripts/api/getAnnouncement.ts
copy_new "$HERE/frontend/scripts/components/server/domain/DomainContainer.tsx" resources/scripts/components/server/domain/DomainContainer.tsx
copy_new "$HERE/frontend/scripts/components/elements/AnnouncementBanner.tsx" resources/scripts/components/elements/AnnouncementBanner.tsx
if [ -f "$HERE/frontend/scripts/components/dashboard/DashboardContainer.tsx" ] && [ ! -f resources/scripts/components/dashboard/DashboardContainer.tsx ]; then
  echo "dashboard custom tersedia, lewati timpa agar panel original aman"
fi
THEME_SRC="$HERE"
if [ ! -d "$HERE/backend" ] && [ -d theme-switcher/backend ]; then THEME_SRC="theme-switcher"; fi
python3 - "$THEME_SRC" <<'PY'
import json, pathlib, sys
src_root = pathlib.Path(sys.argv[1])
for lang in ['en', 'id']:
    src = src_root / f'backend/resources/lang/{lang}.json'
    dst = pathlib.Path(f'resources/lang/{lang}.json')
    if not src.exists() or not dst.exists():
        continue
    try:
        a = json.loads(src.read_text())
        b = json.loads(dst.read_text())
    except Exception as e:
        print(f'bahasa {lang} gagal dibaca: {e}')
        continue
    added = 0
    for k, v in a.items():
        if k not in b:
            b[k] = v
            added += 1
    if added:
        dst.write_text(json.dumps(b, indent=4, ensure_ascii=False) + '\n')
        print(f'bahasa {lang}: tambah {added} kunci')
    else:
        print(f'bahasa {lang}: sudah sinkron')
PY
bash "$HERE/backend/patch.sh"
echo "apply selesai"
