#!/bin/bash
# GarudaDeck rollback ke backup terbaru atau target tertentu, termasuk logo dan favicon.
# Pakai: bash rollback.sh [--auto] [--target /path/backup]
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
BACKUP_ROOT="${BACKUP_ROOT:-$PANEL_DIR/theme-backups}"
AUTO=0
TARGET=""
while [ $# -gt 0 ]; do
  case "$1" in
    --auto) AUTO=1; shift ;;
    --target) TARGET="${2:-}"; shift 2 ;;
    *) break ;;
  esac
done
log() { echo "[garudadeck-rollback] $1"; }
fail() { echo "[garudadeck-rollback] ERROR: $1" >&2; exit 1; }
find_latest() {
  for d in "$BACKUP_ROOT"/pterodactyl-original-*; do
    [ -d "$d" ] || continue
    [ -f "$d/MANIFEST.txt" ] || continue
    echo "$d"
    return 0
  done | head -1
  ls -1dt "$BACKUP_ROOT"/pterodactyl-original-* 2>/dev/null | while read -r p; do
    [ -d "$p" ] && echo "$p" && break
  done | head -1
}
LATEST="$TARGET"
if [ -z "$LATEST" ]; then
  LATEST="$(ls -1dt "$BACKUP_ROOT"/pterodactyl-original-*/ 2>/dev/null | head -1 || true)"
  [ -n "$LATEST" ] || LATEST="$(find_latest || true)"
fi
[ -n "$LATEST" ] || fail "tidak ada backup di $BACKUP_ROOT"
LATEST="${LATEST%/}"
[ -d "$LATEST" ] || fail "backup tidak ketemu: $LATEST (jangan arahkan ke file .tar.gz)"
log "kembali ke $LATEST"
cd "$PANEL_DIR" || fail "tidak bisa masuk $PANEL_DIR"
if ! command -v rsync >/dev/null 2>&1; then
  if [ "$AUTO" = "1" ]; then fail "rsync tidak ada untuk rollback otomatis, install dulu: apt install rsync"; fi
  log "rsync tidak ada, install otomatis"
  apt-get update && apt-get install -y rsync || fail "install rsync gagal"
fi
rsync -a --delete --exclude 'vendor' --exclude 'node_modules' --exclude 'theme-backups' --exclude 'theme-switcher' "$LATEST/" "$PANEL_DIR/" || fail "restore kode gagal"
rm -f public/garudadeck-logo.png resources/scripts/components/elements/GarudaLogo.tsx
log "logo GarudaDeck dibersihkan"
if [ -f "$LATEST/database.sql.gz" ] && [ -f .env ]; then
  command -v mysql >/dev/null 2>&1 || fail "mysql tidak ada, install dulu"
  command -v gunzip >/dev/null 2>&1 || fail "gunzip tidak ada"
  DB_HOST="$(grep -E '^DB_HOST=' .env | cut -d= -f2 | tr -d '"')"
  DB_PORT="$(grep -E '^DB_PORT=' .env | cut -d= -f2 | tr -d '"')"
  DB_NAME="$(grep -E '^DB_DATABASE=' .env | cut -d= -f2 | tr -d '"')"
  DB_USER="$(grep -E '^DB_USERNAME=' .env | cut -d= -f2 | tr -d '"')"
  DB_PASS="$(grep -E '^DB_PASSWORD=' .env | cut -d= -f2- | tr -d '"')"
  log "restore database $DB_NAME"
  MYSQL_PWD="$DB_PASS" mysql -h "${DB_HOST:-127.0.0.1}" -P "${DB_PORT:-3306}" -u "$DB_USER" "$DB_NAME" < <(gunzip -c "$LATEST/database.sql.gz") || fail "restore DB gagal"
else
  log "tanpa arsip DB, lewati restore DB"
fi
if [ ! -d vendor ]; then
  command -v composer >/dev/null 2>&1 || fail "composer tidak ada"
  composer install --no-dev --optimize-autoloader || fail "composer gagal"
fi
php artisan migrate --force || fail "migrasi rollback gagal"
php artisan view:clear >/dev/null 2>&1 || true
php artisan config:clear >/dev/null 2>&1 || true
php artisan route:clear >/dev/null 2>&1 || true
chown -R www-data:www-data storage bootstrap/cache 2>/dev/null || true
log "rollback selesai, panel kembali ke $LATEST"
