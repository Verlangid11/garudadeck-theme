import React, { lazy } from 'react';
import ServerConsole from '@/components/server/console/ServerConsoleContainer';
import DatabasesContainer from '@/components/server/databases/DatabasesContainer';
import ScheduleContainer from '@/components/server/schedules/ScheduleContainer';
import UsersContainer from '@/components/server/users/UsersContainer';
import BackupContainer from '@/components/server/backups/BackupContainer';
import DomainContainer from '@/components/server/domain/DomainContainer';
import NetworkContainer from '@/components/server/network/NetworkContainer';
import StartupContainer from '@/components/server/startup/StartupContainer';
import FileManagerContainer from '@/components/server/files/FileManagerContainer';
import SettingsContainer from '@/components/server/settings/SettingsContainer';
import AccountOverviewContainer from '@/components/dashboard/AccountOverviewContainer';
import AccountSecurityContainer from '@/components/dashboard/AccountSecurityContainer';
import AccountEmailContainer from '@/components/dashboard/AccountEmailContainer';
import AccountTwoFactorContainer from '@/components/dashboard/AccountTwoFactorContainer';
import AccountApiContainer from '@/components/dashboard/AccountApiContainer';
import AccountSSHContainer from '@/components/dashboard/ssh/AccountSSHContainer';
import AccountActivityContainer from '@/components/dashboard/AccountActivityContainer';
import ServerActivityLogContainer from '@/components/server/ServerActivityLogContainer';

// Each of the router files is already code split out appropriately — so
// all of the items above will only be loaded in when that router is loaded.
//
// These specific lazy loaded routes are to avoid loading in heavy screens
// for the server dashboard when they're only needed for specific instances.
//
// FileEditContainer in particular pulls in CodeMirror plus every language
// mode it supports in one chunk — genuinely large, and on a slow connection
// that download+parse happens right at the moment "New File" is clicked,
// which reads as the click itself hanging. webpackPrefetch tells the
// browser to fetch this chunk in idle time as soon as the server dashboard
// loads, so by the time someone actually clicks into Files it's usually
// already cached — it doesn't make the chunk smaller, but it moves the
// wait earlier and off the critical path of the click.
const FileEditContainer = lazy(() => import(/* webpackPrefetch: true */ '@/components/server/files/FileEditContainer'));
const ScheduleEditContainer = lazy(() => import('@/components/server/schedules/ScheduleEditContainer'));

interface RouteDefinition {
    path: string;
    // If undefined is passed this route is still rendered into the router itself
    // but no navigation link is displayed in the sub-navigation menu.
    name: string | undefined;
    // Translation key for the visible label. `name` stays a stable English
    // identifier because the server sub-navigation also uses it to look up an
    // icon; translating it would break that lookup.
    labelKey?: string;
    component: React.ComponentType;
    exact?: boolean;
}

interface ServerRouteDefinition extends RouteDefinition {
    permission: string | string[] | null;
}

interface Routes {
    // All of the routes available under "/account"
    account: RouteDefinition[];
    // All of the routes available under "/server/:id"
    server: ServerRouteDefinition[];
}

export default {
    account: [
        {
            path: '/',
            name: 'Settings',
            component: AccountOverviewContainer,
            exact: true,
        },
        {
            path: '/password',
            name: 'Password and Security',
            component: AccountSecurityContainer,
        },
        {
            path: '/email',
            name: 'Email Address',
            component: AccountEmailContainer,
        },
        {
            path: '/two-step',
            name: 'Two-Step Verification',
            component: AccountTwoFactorContainer,
        },
        {
            path: '/api',
            name: 'API Credentials',
            component: AccountApiContainer,
        },
        {
            path: '/ssh',
            name: 'SSH Keys',
            component: AccountSSHContainer,
        },
        {
            path: '/activity',
            name: 'Activity',
            component: AccountActivityContainer,
        },
    ],
    server: [
        {
            path: '/',
            permission: null,
            name: 'Console',
            labelKey: 'server.tabs.console',
            component: ServerConsole,
            exact: true,
        },
        {
            path: '/files',
            permission: 'file.*',
            name: 'Files',
            labelKey: 'server.tabs.files',
            component: FileManagerContainer,
        },
        {
            path: '/files/:action(edit|new)',
            permission: 'file.*',
            name: undefined,
            component: FileEditContainer,
        },
        {
            path: '/databases',
            permission: 'database.*',
            name: 'Databases',
            labelKey: 'server.tabs.databases',
            component: DatabasesContainer,
        },
        {
            path: '/schedules',
            permission: 'schedule.*',
            name: 'Schedules',
            labelKey: 'server.tabs.schedules',
            component: ScheduleContainer,
        },
        {
            path: '/schedules/:id',
            permission: 'schedule.*',
            name: undefined,
            component: ScheduleEditContainer,
        },
        {
            path: '/users',
            permission: 'user.*',
            name: 'Users',
            labelKey: 'server.tabs.users',
            component: UsersContainer,
        },
        {
            path: '/backups',
            permission: 'backup.*',
            name: 'Backups',
            labelKey: 'server.tabs.backups',
            component: BackupContainer,
        },
        {
            path: '/network',
            permission: 'allocation.*',
            name: 'Network',
            labelKey: 'server.tabs.network',
            component: NetworkContainer,
        },
        {
            path: '/domain',
            permission: 'domain.*',
            name: 'Domain',
            labelKey: 'server.tabs.domain',
            component: DomainContainer,
        },
        {
            path: '/startup',
            permission: 'startup.*',
            name: 'Startup',
            labelKey: 'server.tabs.startup',
            component: StartupContainer,
        },
        {
            path: '/settings',
            permission: ['settings.*', 'file.sftp'],
            name: 'Settings',
            labelKey: 'server.tabs.settings',
            component: SettingsContainer,
        },
        {
            path: '/activity',
            permission: 'activity.*',
            name: 'Activity',
            labelKey: 'server.tabs.activity',
            component: ServerActivityLogContainer,
        },
    ],
} as Routes;
