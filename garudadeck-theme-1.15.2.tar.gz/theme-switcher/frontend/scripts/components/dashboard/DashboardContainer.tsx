import React, { useEffect, useState } from 'react';
import { Server } from '@/api/server/getServer';
import getServers from '@/api/getServers';
import ServerRow from '@/components/dashboard/ServerRow';
import Spinner from '@/components/elements/Spinner';
import PageContentBlock from '@/components/elements/PageContentBlock';
import useFlash from '@/plugins/useFlash';
import { useStoreState } from 'easy-peasy';
import { usePersistedState } from '@/plugins/usePersistedState';
import QuickLinks from '@/components/elements/QuickLinks';
import DashboardSummary from '@/components/dashboard/DashboardSummary';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import useSWR from 'swr';
import { PaginatedResult } from '@/api/http';
import Pagination from '@/components/elements/Pagination';
import { useLocation } from 'react-router-dom';
import { ApplicationStore } from '@/state';
import { useTranslation } from 'react-i18next';
import AnnouncementBanner from '@/components/elements/AnnouncementBanner';

// Same segmented-pill pattern as the drawer's Light/Dark control - both
// options always visible, active one lifted onto a pill, instead of a bare
// switch next to a sentence explaining what it does.
const SegmentedToggle = styled.div<{ $light: boolean }>`
    ${tw`relative flex p-1 rounded-full w-[148px]`};
    background: var(--theme-hover);
`;

// The thumb had `w-[calc(50%-4px)]`, which is invalid CSS: `calc` requires
// whitespace around the minus sign, so the browser dropped the declaration
// and the thumb collapsed to zero width. That left the active label as white
// text on the bare track (1.23:1 in light mode). Written as a plain CSS
// property below so the spacing is guaranteed.
const SegmentedThumb = styled.div<{ $right: boolean }>`
    ${tw`absolute top-1 bottom-1 left-1 rounded-full`};
    width: calc(50% - 4px);
    background: var(--theme-accent);
    transition: transform 250ms cubic-bezier(0.16, 1, 0.3, 1);
    transform: translateX(${(props) => (props.$right ? 'calc(100% + 8px)' : '0')});
`;

const SegmentedOption = styled.button<{ $light: boolean; $active: boolean }>`
    ${tw`relative z-10 flex-1 py-1.5 rounded-full text-xs font-medium transition-colors duration-150`};
    ${(props) => {
        if (props.$active) return tw`text-white`;
        return props.$light ? tw`text-muted-light` : tw`text-muted`;
    }};
`;

export default () => {
    const { t } = useTranslation();
    const { search } = useLocation();
    const defaultPage = Number(new URLSearchParams(search).get('page') || '1');

    const [page, setPage] = useState(!isNaN(defaultPage) && defaultPage > 0 ? defaultPage : 1);
    const { clearFlashes, clearAndAddHttpError } = useFlash();
    const uuid = useStoreState((state) => state.user.data!.uuid);
    const rootAdmin = useStoreState((state) => state.user.data!.rootAdmin);
    const mode = useStoreState((state: ApplicationStore) => state.theme.mode);
    const isLight = mode === 'light';
    const [showOnlyAdmin, setShowOnlyAdmin] = usePersistedState(`${uuid}:show_all_servers`, false);
    const { data: servers, error } = useSWR<PaginatedResult<Server>>(
        ['/api/client/servers', showOnlyAdmin && rootAdmin, page],
        () => getServers({ page, type: showOnlyAdmin && rootAdmin ? 'admin' : undefined })
    );

    useEffect(() => {
        setPage(1);
    }, [showOnlyAdmin]);

    useEffect(() => {
        if (!servers) return;
        if (servers.pagination.currentPage > 1 && !servers.items.length) {
            setPage(1);
        }
    }, [servers?.pagination.currentPage]);

    useEffect(() => {
        // Don't use react-router to handle changing this part of the URL, otherwise it
        // triggers a needless re-render. We just want to track this in the URL incase the
        // user refreshes the page.
        window.history.replaceState(null, document.title, `/${page <= 1 ? '' : `?page=${page}`}`);
    }, [page]);

    useEffect(() => {
        if (error) clearAndAddHttpError({ key: 'dashboard', error });
        if (!error) clearFlashes('dashboard');
    }, [error]);

    return (
        <PageContentBlock title={t('dashboard.title')} showFlashKey={'dashboard'}>
            <AnnouncementBanner />
            <QuickLinks />
            <DashboardSummary active={!showOnlyAdmin} />
            {rootAdmin && (
                <div css={tw`mb-3 flex justify-end`}>
                    <SegmentedToggle $light={isLight}>
                        <SegmentedThumb $right={!!showOnlyAdmin} />
                        <SegmentedOption
                            type={'button'}
                            $light={isLight}
                            $active={!showOnlyAdmin}
                            onClick={() => showOnlyAdmin && setShowOnlyAdmin(false)}
                        >
                            {t('dashboard.mine')}
                        </SegmentedOption>
                        <SegmentedOption
                            type={'button'}
                            $light={isLight}
                            $active={!!showOnlyAdmin}
                            onClick={() => !showOnlyAdmin && setShowOnlyAdmin(true)}
                        >
                            {t('dashboard.all')}
                        </SegmentedOption>
                    </SegmentedToggle>
                </div>
            )}
            {!servers ? (
                <Spinner centered size={'large'} />
            ) : (
                <Pagination data={servers} onPageSelect={setPage}>
                    {({ items }) =>
                        items.length > 0 ? (
                            items.map((server, index) => (
                                <ServerRow key={server.uuid} server={server} css={index > 0 ? tw`mt-3.5` : undefined} />
                            ))
                        ) : (
                            <p css={[tw`text-center text-sm`, isLight ? tw`text-muted-light` : tw`text-muted`]}>
                                {showOnlyAdmin ? t('dashboard.empty_all') : t('dashboard.empty_mine')}
                            </p>
                        )
                    }
                </Pagination>
            )}
        </PageContentBlock>
    );
};
