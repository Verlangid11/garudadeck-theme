import React, { useState } from 'react';
import useSWR from 'swr';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import { getAnnouncement } from '@/api/getAnnouncement';
import Spinner from '@/components/elements/Spinner';
import { usePersistedState } from '@/plugins/usePersistedState';
import { useTranslation } from 'react-i18next';

const Bar = styled.div`
    ${tw`flex items-start gap-3 px-4 py-3 mb-4 border`};
    border-radius: 2px;
    border-color: var(--status-seam);
    border-left-width: 4px;
    border-left-color: var(--theme-accent);
    background: var(--theme-hover);
`;

const BarCopy = styled.div`
    ${tw`min-w-0 flex-1`};
`;

const BarLabel = styled.p`
    ${tw`text-[10px] font-mono uppercase`};
    color: var(--theme-text-muted);
`;

const BarText = styled.p`
    ${tw`text-sm leading-relaxed mt-0.5 break-words`};
    color: var(--theme-text-strong);
`;

const Dismiss = styled.button`
    ${tw`text-xs flex-shrink-0 px-2 py-1 border`};
    border-radius: 2px;
    border-color: var(--status-seam);
    color: var(--theme-text-muted);
    &:hover {
        color: var(--theme-text-strong);
        background: var(--theme-surface-raised);
    }
`;

// One global banner, shown on the dashboard and on the server console. The
// admin picks tone, colors, and font per row, and the client renders exactly
// those values instead of a hardcoded style. Dismiss is per browser only:
// clearing it here never touches the server value, so the next login still
// shows a fresh announcement.
const AnnouncementBanner = ({ compact = false }: { compact?: boolean }) => {
    const { t } = useTranslation();
    const { data } = useSWR(['/api/client/announcement'], () => getAnnouncement());
    const [dismissed, setDismissed] = usePersistedState<string | null>('pterodactyl:announcement:dismissed', null);
    const [busy, setBusy] = useState(false);

    if (!data || !data.message) return null;
    if (dismissed === `${data.tone}:${data.font}:${data.accentColor}:${data.message}`) return null;

    const fontFamily =
        data.font === 'mono'
            ? "'JetBrains Mono', ui-monospace, monospace"
            : data.font === 'display'
            ? "'Inter Tight', 'Inter', system-ui, sans-serif"
            : "'Inter', system-ui, sans-serif";

    return (
        <Bar
            role={'status'}
            css={compact ? tw`mb-3` : undefined}
            style={{
                borderLeftColor: data.accentColor,
                background: data.backgroundColor ?? undefined,
                color: data.textColor ?? undefined,
                fontFamily,
            }}
        >
            {busy ? (
                <Spinner size={'small'} />
            ) : (
                <>
                    <BarCopy>
                        <BarLabel style={data.textColor ? { color: data.textColor } : undefined}>
                            {data.title ? `${data.title} · ${data.tone}` : t('announcement.label')}
                        </BarLabel>
                        <BarText style={data.textColor ? { color: data.textColor } : undefined}>{data.message}</BarText>
                    </BarCopy>
                    <Dismiss
                        type={'button'}
                        aria-label={t('announcement.dismiss')}
                        onClick={() => {
                            setBusy(true);
                            setDismissed(`${data.tone}:${data.font}:${data.accentColor}:${data.message}`);
                            setBusy(false);
                        }}
                    >
                        {t('announcement.dismiss')}
                    </Dismiss>
                </>
            )}
        </Bar>
    );
};

export default AnnouncementBanner;
