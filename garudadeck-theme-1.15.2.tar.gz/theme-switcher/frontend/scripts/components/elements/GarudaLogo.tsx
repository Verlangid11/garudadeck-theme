import React from 'react';
import tw from 'twin.macro';
import styled from 'styled-components/macro';

const Img = styled.img<{ $size: number }>`
    ${tw`object-contain flex-shrink-0`};
    width: ${(p) => p.$size}px;
    height: ${(p) => p.$size}px;
    border-radius: 6px;
`;

export default ({ size = 36 }: { size?: number }) => <Img src='/garudadeck-logo.png' alt='GarudaDeck' $size={size} />;
