import React, { useEffect, useState } from 'react';
import useSWR from 'swr';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import { Form, Formik } from 'formik';
import { object, string } from 'yup';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import TitledGreyBox from '@/components/elements/TitledGreyBox';
import { Button } from '@/components/elements/button/index';
import Can from '@/components/elements/Can';
import CopyOnClick from '@/components/elements/CopyOnClick';
import Code from '@/components/elements/Code';
import Spinner from '@/components/elements/Spinner';
import EmptyState from '@/components/elements/EmptyState';
import { Dialog } from '@/components/elements/dialog';
import Field from '@/components/elements/Field';
import Label from '@/components/elements/Label';
import { useFlashKey } from '@/plugins/useFlash';
import { ServerContext } from '@/state/server';
import { useTranslation } from 'react-i18next';
import {
    deleteServerDomain,
    getServerDomain,
    saveServerDomain,
    ServerDomain,
    verifyServerDomain,
} from '@/api/server/domain';

const Row = styled.div`
    ${tw`flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between py-2 border-b`};
    border-color: var(--status-seam);

    &:last-child {
        ${tw`border-b-0`};
    }
`;

const RowLabel = styled.span`
    ${tw`text-xs`};
    color: var(--theme-text-muted);
`;

const RowValue = styled.span`
    ${tw`text-sm font-mono break-all text-right`};
    color: var(--theme-text);
`;

// The verified address players type into their game client: domain plus the
// primary allocation port, on one copyable line.
const JoinAddress = styled.div`
    ${tw`flex flex-wrap items-center gap-3 p-4 border`};
    border-radius: 2px;
    background: var(--status-ok-tint);
    border-color: var(--status-ok);
`;

const StatusBadge = styled.span<{ $tone: 'ok' | 'warn' | 'bad' }>`
    ${tw`inline-flex items-center h-6 px-2 text-[10px] font-mono uppercase tracking-wide border`};
    border-radius: 2px;
    background: ${({ $tone }) =>
        $tone === 'ok' ? 'var(--status-ok-tint)' : $tone === 'warn' ? 'var(--theme-hover)' : 'var(--status-bad-tint)'};
    border-color: ${({ $tone }) =>
        $tone === 'ok' ? 'var(--status-ok)' : $tone === 'warn' ? 'var(--status-seam)' : 'var(--status-bad)'};
    color: ${({ $tone }) =>
        $tone === 'ok' ? 'var(--status-ok)' : $tone === 'warn' ? 'var(--theme-text-muted)' : 'var(--status-bad)'};
`;

const statusTone = (status: ServerDomain['status']): 'ok' | 'warn' | 'bad' =>
    status === 'verified' ? 'ok' : status === 'failed' ? 'bad' : 'warn';

// One setup in chronological order: saved hostname, then the live DNS state.
// A row that never verified stops at step one, so the page never shows a
// green badge the DNS did not earn. Dates use the active locale.
const Timeline = styled.ol`
    ${tw`mt-4 space-y-0 list-none p-0 m-0`};
`;

const TimelineItem = styled.li<{ $done: boolean }>`
    ${tw`relative flex gap-3 pb-4 pl-8`};
    &:last-child {
        ${tw`pb-0`};
    }
    &::before {
        content: '';
        position: absolute;
        left: 7px;
        top: 22px;
        bottom: 0;
        width: 2px;
        background: var(--status-seam);
    }
    &:last-child::before {
        display: none;
    }
`;

const TimelineDot = styled.span<{ $tone: 'ok' | 'warn' | 'bad' }>`
    ${tw`absolute left-0 top-1 flex h-4 w-4 items-center justify-center rounded-full border`};
    background: ${({ $tone }) =>
        $tone === 'ok' ? 'var(--status-ok)' : $tone === 'bad' ? 'var(--status-bad)' : 'var(--theme-hover)'};
    border-color: ${({ $tone }) =>
        $tone === 'ok' ? 'var(--status-ok)' : $tone === 'bad' ? 'var(--status-bad)' : 'var(--status-seam)'};
    &::after {
        content: '';
        width: 6px;
        height: 6px;
        border-radius: 9999px;
        background: ${({ $tone }) => ($tone === 'warn' ? 'var(--theme-text-muted)' : '#fff')};
    }
`;

const TimelineTitle = styled.p`
    ${tw`text-sm font-medium m-0`};
    color: var(--theme-text-strong);
`;

const TimelineBody = styled.p`
    ${tw`text-xs mt-0.5 mb-0 leading-relaxed`};
    color: var(--theme-text-muted);
`;

const formatDateTime = (value: string | null): string | null => {
    if (!value) return null;
    const date = new Date(value);

    return Number.isNaN(date.getTime()) ? null : date.toLocaleString();
};

const DomainContainer = () => {
    const { t } = useTranslation();
    const uuid = ServerContext.useStoreState((state) => state.server.data!.uuid);
    const { clearFlashes, clearAndAddHttpError } = useFlashKey('server:domain');
    const [verifying, setVerifying] = useState(false);
    const [confirmDelete, setConfirmDelete] = useState(false);
    const { data, error, mutate } = useSWR(['server-domain', uuid], () => getServerDomain(uuid), {
        // Keep the verify button honest after the panel re-checks a row in the
        // background: refetch when the tab regains focus.
        revalidateOnFocus: true,
    });

    useEffect(() => {
        if (error) clearAndAddHttpError(error);
    }, [error]);

    const onSave = (domain: string) => {
        clearFlashes();
        return saveServerDomain(uuid, domain).then((next) => mutate(next, false));
    };

    const onVerify = () => {
        clearFlashes();
        setVerifying(true);
        verifyServerDomain(uuid)
            .then((next) => mutate(next, false))
            .catch(clearAndAddHttpError)
            .then(() => setVerifying(false));
    };

    const onCopyAll = () => {
        if (!data || data.instructions.length === 0) return;

        // One paste for the whole DNS setup: each line names the record type,
        // the host, and the exact value, so the owner can paste it into a
        // ticket or a provider form without retyping tokens.
        const lines = data.instructions.map((step) => `${step.type} ${step.host} ${step.value}`);
        const text = lines.join('\n');

        try {
            if (navigator.clipboard?.writeText) {
                navigator.clipboard.writeText(text);
            } else {
                const area = document.createElement('textarea');
                area.value = text;
                document.body.appendChild(area);
                area.select();
                document.execCommand('copy');
                document.body.removeChild(area);
            }
        } catch {
            // Clipboard can be blocked in an insecure context. The per-row
            // CopyOnClick controls still work, so a failure here stays silent.
        }
    };

    const verifiedAt = formatDateTime(data?.verifiedAt ?? null);
    const checkedAt = formatDateTime(data?.lastCheckedAt ?? null);

    const onDelete = () => {
        clearFlashes();
        setConfirmDelete(false);
        deleteServerDomain(uuid)
            .then(() => mutate(undefined, true))
            .catch(clearAndAddHttpError);
    };

    return (
        <ServerContentBlock
            showFlashKey={'server:domain'}
            title={t('server.domain.title')}
            code={'08'}
            description={t('server.domain.description')}
        >
            {!data ? (
                <Spinner size={'large'} centered />
            ) : (
                <>
                    {data.joinAddress && (
                        <JoinAddress>
                            <div css={tw`min-w-0 flex-1`}>
                                <Label>{t('server.domain.join_address')}</Label>
                                <CopyOnClick text={data.joinAddress}>
                                    <Code dark>{data.joinAddress}</Code>
                                </CopyOnClick>
                            </div>
                            <StatusBadge $tone={statusTone(data.status)}>
                                {t(`server.domain.status_${data.status}`)}
                            </StatusBadge>
                        </JoinAddress>
                    )}
                    <div css={tw`mt-4`}>
                        <TitledGreyBox title={t('server.domain.link_title')}>
                            <Can action={'domain.update'}>
                                <Formik
                                    enableReinitialize
                                    initialValues={{ domain: data.domain ?? '' }}
                                    validationSchema={object().shape({
                                        domain: string().required(t('server.domain.hostname_required')),
                                    })}
                                    onSubmit={({ domain }, { setSubmitting }) => {
                                        onSave(domain)
                                            .catch(clearAndAddHttpError)
                                            .then(() => setSubmitting(false));
                                    }}
                                >
                                    {({ isSubmitting }) => (
                                        <Form>
                                            <Field
                                                id={'domain'}
                                                name={'domain'}
                                                label={t('server.domain.hostname')}
                                                placeholder={'play.example.com'}
                                                autoComplete={'off'}
                                            />
                                            <div css={tw`mt-3 flex justify-end`}>
                                                <Button type={'submit'} disabled={isSubmitting}>
                                                    {t('server.domain.save')}
                                                </Button>
                                            </div>
                                        </Form>
                                    )}
                                </Formik>
                            </Can>
                            {data.domain && (
                                <div css={tw`mt-4`}>
                                    <Row>
                                        <RowLabel>{t('server.domain.hostname')}</RowLabel>
                                        <CopyOnClick text={data.domain}>
                                            <RowValue>{data.domain}</RowValue>
                                        </CopyOnClick>
                                    </Row>
                                    <Row>
                                        <RowLabel>{t('server.domain.status')}</RowLabel>
                                        <StatusBadge $tone={statusTone(data.status)}>
                                            {t(`server.domain.status_${data.status}`)}
                                        </StatusBadge>
                                    </Row>
                                    {checkedAt && (
                                        <Row>
                                            <RowLabel>{t('server.domain.last_checked')}</RowLabel>
                                            <RowValue>{checkedAt}</RowValue>
                                        </Row>
                                    )}
                                    {data.lastError && (
                                        <Row>
                                            <RowLabel>{t('server.domain.last_error')}</RowLabel>
                                            <RowValue>{data.lastError}</RowValue>
                                        </Row>
                                    )}
                                    <p css={tw`text-xs mt-2`} style={{ color: 'var(--theme-text-muted)' }}>
                                        {t('server.domain.recheck_note')}
                                    </p>
                                    <Timeline aria-label={t('server.domain.timeline_title')}>
                                        <TimelineItem $done>
                                            <TimelineDot $tone={'ok'} />
                                            <div>
                                                <TimelineTitle>{t('server.domain.step_saved')}</TimelineTitle>
                                                <TimelineBody>{t('server.domain.step_saved_body')}</TimelineBody>
                                            </div>
                                        </TimelineItem>
                                        <TimelineItem $done={data.status === 'verified'}>
                                            <TimelineDot $tone={statusTone(data.status)} />
                                            <div>
                                                <TimelineTitle>
                                                    {data.status === 'verified'
                                                        ? t('server.domain.step_verified')
                                                        : data.status === 'failed'
                                                        ? t('server.domain.step_failed')
                                                        : t('server.domain.step_waiting')}
                                                </TimelineTitle>
                                                <TimelineBody>
                                                    {data.status === 'verified'
                                                        ? `${t('server.domain.step_verified_body')}${
                                                              verifiedAt ? ` ${verifiedAt}` : ''
                                                          }`
                                                        : data.lastError ?? t('server.domain.step_saved_body')}
                                                </TimelineBody>
                                            </div>
                                        </TimelineItem>
                                    </Timeline>
                                </div>
                            )}
                            {!data.domain && (
                                <EmptyState
                                    title={t('server.domain.empty_title')}
                                    message={t('server.domain.empty_body')}
                                />
                            )}
                        </TitledGreyBox>
                    </div>
                    {data.instructions.length > 0 && (
                        <div css={tw`mt-4`}>
                            <TitledGreyBox title={t('server.domain.dns_title')}>
                                <p css={tw`text-xs leading-relaxed mb-3`} style={{ color: 'var(--theme-text-muted)' }}>
                                    {t('server.domain.dns_hint')}
                                </p>
                                {data.instructions.map((step) => (
                                    <Row key={`${step.type}:${step.host}`}>
                                        <div css={tw`min-w-0`}>
                                            <RowLabel>
                                                {step.type} {t('server.domain.record_for')} {step.host}
                                            </RowLabel>
                                            <CopyOnClick text={step.value}>
                                                <Code dark>{step.value}</Code>
                                            </CopyOnClick>
                                            <p css={tw`text-xs mt-1`} style={{ color: 'var(--theme-text-muted)' }}>
                                                {step.note}
                                            </p>
                                        </div>
                                    </Row>
                                ))}
                                <div css={tw`mt-3 flex flex-wrap justify-end gap-2`}>
                                    <Button.Text onClick={onCopyAll} disabled={data.instructions.length === 0}>
                                        {t('server.domain.copy_all')}
                                    </Button.Text>
                                    <Can action={'domain.update'}>
                                        <Button.Text onClick={onVerify} disabled={verifying}>
                                            {verifying ? <Spinner size={'small'} /> : t('server.domain.verify_now')}
                                        </Button.Text>
                                        {data.domain && (
                                            <Button.Danger
                                                variant={Button.Variants.Secondary}
                                                size={Button.Sizes.Small}
                                                onClick={() => setConfirmDelete(true)}
                                            >
                                                {t('common.delete')}
                                            </Button.Danger>
                                        )}
                                    </Can>
                                </div>
                            </TitledGreyBox>
                        </div>
                    )}
                    <Dialog.Confirm
                        open={confirmDelete}
                        onClose={() => setConfirmDelete(false)}
                        title={t('server.domain.delete_title')}
                        confirm={t('common.delete')}
                        onConfirmed={onDelete}
                    >
                        {t('server.domain.delete_body')}
                    </Dialog.Confirm>
                </>
            )}
        </ServerContentBlock>
    );
};

export default DomainContainer;
