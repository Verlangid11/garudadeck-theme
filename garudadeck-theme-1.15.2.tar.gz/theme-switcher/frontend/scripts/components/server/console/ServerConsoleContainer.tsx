import React, { memo } from 'react';
import { ServerContext } from '@/state/server';
import Can from '@/components/elements/Can';
import ServerContentBlock from '@/components/elements/ServerContentBlock';
import isEqual from 'react-fast-compare';
import Spinner from '@/components/elements/Spinner';
import Features from '@feature/Features';
import Console from '@/components/server/console/Console';
import PowerButtons from '@/components/server/console/PowerButtons';
import ServerInstruments from '@/components/server/console/ServerInstruments';
import ServerFactsPanel from '@/components/server/console/ServerFactsPanel';
import ServerUptimePanel from '@/components/server/console/ServerUptimePanel';
import ServerResourcePanel from '@/components/server/console/ServerResourcePanel';
import ServerLogPanel from '@/components/server/console/ServerLogPanel';
import { Alert } from '@/components/elements/alert';
import { getServerStatusMeta, statusToneColor, statusToneTint, StatusTone } from '@/lib/serverStatus';
import StatusTag from '@/components/elements/StatusTag';
import tw from 'twin.macro';
import styled from 'styled-components/macro';
import { useTranslation } from 'react-i18next';
import AnnouncementBanner from '@/components/elements/AnnouncementBanner';

export type PowerAction = 'start' | 'stop' | 'restart' | 'kill';

const StatusRow = styled.div<{ $tone: StatusTone }>`
    ${tw`flex items-start gap-3 px-3 py-2.5 mb-4 border`};
    border-radius: 2px;
    border-color: var(--status-seam);
    border-left-width: 4px;
    border-left-color: ${(props) => statusToneColor(props.$tone)};
    background: ${(props) => statusToneTint(props.$tone)};
`;

const StatusCopy = styled.div`
    ${tw`min-w-0`};
`;

const StatusLabel = styled.span<{ $tone: StatusTone }>`
    ${tw`text-xs font-semibold`};
    color: ${(props) => (props.$tone === 'red' ? statusToneColor('red') : 'var(--theme-text-strong)')};
`;

const StatusHint = styled.span`
    ${tw`text-xs ml-1.5`};
    color: var(--theme-text-muted);
`;

const ServerConsoleContainer = () => {
    const { t } = useTranslation();
    const name = ServerContext.useStoreState((state) => state.server.data!.name);
    const description = ServerContext.useStoreState((state) => state.server.data!.description);
    const isInstalling = ServerContext.useStoreState((state) => state.server.isInstalling);
    const persistedStatus = ServerContext.useStoreState((state) => state.server.data!.status);
    const isTransferring = ServerContext.useStoreState((state) => state.server.data!.isTransferring);
    const eggFeatures = ServerContext.useStoreState((state) => state.server.data!.eggFeatures, isEqual);
    const isNodeUnderMaintenance = ServerContext.useStoreState((state) => state.server.data!.isNodeUnderMaintenance);
    const liveStatus = ServerContext.useStoreState((state) => state.status.value);
    // The terminal and instrument cards below are intentionally fixed-dark
    // (a terminal is dark by convention), so the header above them uses the
    // theme tokens directly rather than branching on the mode.

    const status = getServerStatusMeta(
        {
            persisted: persistedStatus,
            live: liveStatus,
            isTransferring,
            isNodeUnderMaintenance,
        },
        t
    );

    return (
        <ServerContentBlock
            title={t('server.console.title')}
            code={'01'}
            pageTitle={name}
            description={description || t('server.console.description')}
            actions={
                <Can action={['control.start', 'control.stop', 'control.restart']} matchAny>
                    <PowerButtons className={'flex gap-2 flex-1 sm:flex-none sm:w-[22rem]'} />
                </Can>
            }
            headChildren={
                <StatusRow $tone={status.tone} role={'status'} css={tw`mt-4`}>
                    <StatusTag tone={status.tone} code={status.code} />
                    <StatusCopy>
                        <StatusLabel $tone={status.tone}>{status.label}</StatusLabel>
                        <StatusHint>{status.hint}</StatusHint>
                    </StatusCopy>
                </StatusRow>
            }
        >
            <AnnouncementBanner compact />
            {(isNodeUnderMaintenance ||
                isInstalling ||
                isTransferring ||
                persistedStatus === 'reinstall_failed' ||
                persistedStatus === 'restoring_backup') && (
                <Alert
                    type={
                        persistedStatus === 'install_failed' || persistedStatus === 'reinstall_failed'
                            ? 'danger'
                            : 'warning'
                    }
                    className={'mb-4'}
                >
                    {isNodeUnderMaintenance
                        ? t('server.console.maintenance')
                        : persistedStatus === 'install_failed' || persistedStatus === 'reinstall_failed'
                        ? t('server.console.install_failed')
                        : isInstalling
                        ? t('server.console.installing')
                        : isTransferring
                        ? t('server.console.transferring')
                        : t('server.console.restoring')}
                </Alert>
            )}
            {/* Terminal is the primary focus (a console page's whole reason
                for existing), so it gets the wide column; the resource
                cards ride along in a narrower rail next to it on larger
                screens and drop below it on mobile - not stacked as two
                separate "sections" like the old layout. */}
            {/* The terminal/CPU/Memory/etc instruments are deliberately
                fixed-dark (see the note in style.module.css) regardless of
                the page's own light/dark toggle - which reads fine against
                a dark page but looked like a mismatched dark blob dropped
                onto a light one. Framing it in a themed "bezel" makes that
                intentional: a dark panel inside a housing that itself still
                respects the toggle, the way a screen looks embedded in a
                physical device rather than floating loose on the page. */}
            {/* One flat frame instead of the old gradient (primary-50 to
                white to primary-50) with a colored glow: that gradient was
                decoration on a page whose only job is the terminal, and its
                glow was the exact "AI default" treatment the audit flags.
                A plain raised surface reads as a device bay and gets out of
                the way. */}
            <div
                className={'p-2.5 sm:p-3 border'}
                style={{
                    borderRadius: 2,
                    background: 'var(--theme-surface-raised)',
                    borderColor: 'var(--status-seam)',
                }}
            >
                <div className={'grid grid-cols-1 lg:grid-cols-4 gap-4'}>
                    <div className={'lg:col-span-3'}>
                        <Spinner.Suspense>
                            <Console />
                        </Spinner.Suspense>
                        {/* The log tail sits under the terminal rather than in
                            the rail: the lines are wide, and the terminal only
                            shows output while the container is alive. */}
                        <ServerLogPanel />
                    </div>
                    <div className={'lg:col-span-1'}>
                        <Spinner.Suspense>
                            <ServerInstruments />
                        </Spinner.Suspense>
                        <ServerUptimePanel />
                        <ServerResourcePanel />
                        <ServerFactsPanel />
                    </div>
                </div>
            </div>
            <Features enabled={eggFeatures} />
        </ServerContentBlock>
    );
};

export default memo(ServerConsoleContainer, isEqual);
