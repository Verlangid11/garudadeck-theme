import http from '@/api/http';

export type AnnouncementTone = 'info' | 'success' | 'warning' | 'danger';
export type AnnouncementFont = 'sans' | 'mono' | 'display';

export interface Announcement {
    message: string | null;
    title: string | null;
    tone: AnnouncementTone;
    font: AnnouncementFont;
    accentColor: string;
    backgroundColor: string | null;
    textColor: string | null;
    enabled: boolean;
}

export const getAnnouncement = async (): Promise<Announcement> => {
    const { data } = await http.get('/api/client/announcement');
    const tone = data.attributes.tone;
    const font = data.attributes.font;

    return {
        message: data.attributes.message ?? null,
        title: data.attributes.title ?? null,
        tone: tone === 'success' || tone === 'warning' || tone === 'danger' ? tone : 'info',
        font: font === 'mono' || font === 'display' ? font : 'sans',
        accentColor: data.attributes.accent_color ?? '#2563eb',
        backgroundColor: data.attributes.background_color ?? null,
        textColor: data.attributes.text_color ?? null,
        enabled: Boolean(data.attributes.enabled),
    };
};
