import http, { FractalResponseData } from '@/api/http';

export interface ServerDomainInstruction {
    type: string;
    host: string;
    value: string;
    note: string;
}

export interface ServerDomain {
    domain: string | null;
    status: 'pending' | 'verified' | 'failed' | null;
    joinAddress: string | null;
    lastError: string | null;
    verifiedAt: string | null;
    lastCheckedAt: string | null;
    instructions: ServerDomainInstruction[];
    token: string | null;
    verified?: boolean;
}

export interface ServerDomainPayload {
    object: 'server_custom_domain';
    attributes: {
        domain: string | null;
        status: ServerDomain['status'];
        join_address: string | null;
        last_error: string | null;
        verified_at: string | null;
        last_checked_at: string | null;
        instructions: ServerDomainInstruction[];
        token: string | null;
        verified?: boolean;
    };
}

export const rawDataToServerDomain = (data: ServerDomainPayload): ServerDomain => ({
    domain: data.attributes.domain,
    status: data.attributes.status,
    joinAddress: data.attributes.join_address,
    lastError: data.attributes.last_error,
    verifiedAt: data.attributes.verified_at,
    lastCheckedAt: data.attributes.last_checked_at,
    instructions: data.attributes.instructions ?? [],
    token: data.attributes.token,
    verified: data.attributes.verified,
});

export const getServerDomain = async (uuid: string): Promise<ServerDomain> => {
    const { data } = await http.get(`/api/client/servers/${uuid}/domain`);

    return rawDataToServerDomain(data);
};

export const saveServerDomain = async (uuid: string, domain: string): Promise<ServerDomain> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/domain`, { domain });

    return rawDataToServerDomain(data);
};

export const verifyServerDomain = async (uuid: string): Promise<ServerDomain> => {
    const { data } = await http.post(`/api/client/servers/${uuid}/domain/verify`);

    return rawDataToServerDomain(data);
};

export const deleteServerDomain = async (uuid: string): Promise<void> => {
    await http.delete(`/api/client/servers/${uuid}/domain`);
};

export type { FractalResponseData };
