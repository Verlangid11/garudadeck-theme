# GarudaDeck Theme Switcher
Paket tema GarudaDeck by verlangid untuk panel Pterodactyl original dari GitHub.
Installer cerdas: deteksi OS, cek versi panel dan PHP, backup full otomatis, pasang backend plus frontend bertahap, dan bisa rollback.
## Struktur
- backend: domain per server plus pengumuman global
- frontend: tab Domain plus banner pengumuman
- installer: check, backup, apply, install, rollback
- docs: panduan plus matriks versi
## Alur
1. Cek OS Ubuntu 20.04, 22.04, 24.04, Debian 11, 12.
2. Cek panel 1.11.0 sampai 1.15.99, tolak di luar itu.
3. Cek PHP 8.2 atau 8.3, Node opsional.
4. Backup kode plus DB ke theme-backups sebelum ubah.
5. Pasang backend: migrasi, controller, route, permission.
6. Pasang frontend: komponen GarudaDeck, banner, tab Domain.
7. Migrasi force, clear cache, build bila yarn ada.
8. Verifikasi route pengumuman dan syntax model.
