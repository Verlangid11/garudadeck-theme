#!/bin/bash
# GarudaDeck entry point. Pakai: bash install.sh [install|check|backup|rollback]
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
case "${1:-install}" in
  install) bash "$HERE/installer/install.sh" ;;
  rollback) bash "$HERE/installer/rollback.sh" ;;
  check) bash "$HERE/installer/check.sh" ;;
  backup) bash "$HERE/installer/backup.sh" ;;
  *) echo "Pakai: $0 [install|check|backup|rollback]"; exit 1 ;;
esac
