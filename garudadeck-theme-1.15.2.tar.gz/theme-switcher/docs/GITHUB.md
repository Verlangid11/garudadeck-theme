# Terbitkan GarudaDeck ke GitHub
## Push awal
cd /root/GarudaDeck-Github-Repo
git init
git add .
git commit -m "GarudaDeck theme 1.15.2 by verlangid"
git branch -M main
git remote add origin https://github.com/Verlangid11/garudadeck-theme.git
git push -u origin main
## Buat release
git tag v1.15.2
git push origin v1.15.2
Workflow .github/workflows/release.yml membuat garudadeck-theme-1.15.2.tar.gz otomatis.
Bila workflow belum jalan, upload manual arsip dari /root ke halaman release.
## Uji satu perintah
bash <(curl -fsSL https://raw.githubusercontent.com/Verlangid11/garudadeck-theme/main/install.sh) check
