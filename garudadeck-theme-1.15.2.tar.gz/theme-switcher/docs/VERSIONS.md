# Matriks versi dan OS GarudaDeck
## Panel didukung
| Panel | Status | Catatan |
| --- | --- | --- |
| 1.11.x | Didukung | Route client dan admin stabil, migrasi domain dan pengumuman jalan. |
| 1.12.x | Didukung | Struktur route sama, perlu composer install ulang bila vendor hilang. |
| 1.13.x | Didukung | Cache route wajib dibersihkan, installer sudah otomatis. |
| 1.14.x | Didukung | Verifikasi route:list setelah install. |
| 1.15.x | Didukung penuh | Lingkungan aktif, panel 1.15.2 PHP 8.3 Node 22 teruji. |
## OS didukung
| OS | Status | Catatan |
| --- | --- | --- |
| Ubuntu 20.04 | Didukung | PHP 8.2 dari PPA Ondrej, butuh rsync dan python3. |
| Ubuntu 22.04 | Didukung | PHP 8.2 atau 8.3, Node 18 atau 22. |
| Ubuntu 24.04 | Didukung penuh | Teruji langsung, PHP 8.3, Node 22. |
| Debian 11 | Didukung | Butuh repo Sury untuk PHP 8.2. |
| Debian 12 | Didukung | PHP 8.2 bawaan, Node 18 atau 22. |
## Tool wajib dan fallback
- Wajib: php, tar, python3, curl. Gagal bila tidak ada, dengan pesan apt install.
- Peringatan: composer bila vendor hilang, rsync untuk rollback, mysql dan mysqldump untuk DB.
- Backup kode selalu jalan walau DB gagal, DB_OK tercatat di MANIFEST.
- Yarn opsional, gagal build tidak menggagalkan install.
- Rollback otomatis bila install gagal di tengah, nonaktifkan dengan AUTO_ROLLBACK=0.
## Uji yang sudah jalan
- bash -n semua skrip lolos.
- check lolos Ubuntu 24.04 panel 1.15.2 PHP 8.3 Node 22.
- backup kode plus DB sukses 12 MB kode plus 950 KB DB.
- branding logo plus favicon 33 file plus patch login lolos eslint.
- route admin.announcements ada, syntax model bersih.
- rollback restore DB jalan, logo dibersihkan.
