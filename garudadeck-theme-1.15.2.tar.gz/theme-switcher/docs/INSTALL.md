# Cara install GarudaDeck public dist
## Satu perintah tanpa token, auto sudo
curl -fsSL https://raw.githubusercontent.com/Verlangid11/garudadeck-dist/main/install.sh | bash
## Aksi
- Cek: tambah `| bash -s -- check`
- Backup: tambah `| bash -s -- backup`
- Rollback: tambah `| bash -s -- rollback`
- Panel beda path: `PANEL_DIR=/var/www/panel curl ... | bash -s -- install`
- Tanpa rollback otomatis: `AUTO_ROLLBACK=0 curl ... | bash`
## Urutan aman installer
1. check tolak OS, panel, PHP, tool wajib sebelum ubah apa pun.
2. backup kode plus DB ke theme-backups dengan MANIFEST dan db_backup yes atau no.
3. apply salin file hanya bila belum ada, patch idempoten, gabung bahasa tanpa timpa.
4. branding pasang logo, favicon 33 file, komponen GarudaLogo, patch login.
5. composer hanya bila vendor hilang, migrasi force.
6. clear cache, yarn build opsional, verifikasi syntax dan route.
7. gagal di tengah otomatis rollback ke backup barusan.
## Rollback manual
- Terbaru: `curl .../install.sh | bash -s -- rollback`
- Target: `PANEL_DIR=/var/www/pterodactyl BACKUP_ROOT=/var/www/pterodactyl/theme-backups bash theme-switcher/installer/rollback.sh --target /path/backup`
- Rollback hapus logo, restore kode dengan rsync, restore DB bila ada database.sql.gz, migrate force, clear cache.
