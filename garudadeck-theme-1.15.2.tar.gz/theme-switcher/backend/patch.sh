#!/bin/bash
# Patch backend idempoten: aman dijalankan ulang, cocok untuk panel 1.11 sampai 1.15.
set -euo pipefail
PANEL_DIR="${PANEL_DIR:-/var/www/pterodactyl}"
cd "$PANEL_DIR"

patch_route_client() {
    if ! grep -q "ServerDomainController" routes/api-client.php; then
        python3 - <<'PY'
import pathlib
p = pathlib.Path('routes/api-client.php')
s = p.read_text()
anchor = "    Route::group(['prefix' => '/network'], function () {"
block = """    Route::group(['prefix' => '/domain'], function () {
        Route::get('/', [Client\\Servers\\ServerDomainController::class, 'index']);
        Route::middleware('throttle:10,60,server-domain-verify')
            ->post('/verify', [Client\\Servers\\ServerDomainController::class, 'verify']);
        Route::post('/', [Client\\Servers\\ServerDomainController::class, 'store']);
        Route::delete('/', [Client\\Servers\\ServerDomainController::class, 'destroy']);
    })

"""
assert anchor in s, 'anchor network tidak ketemu'
s = s.replace(anchor, block + anchor)
p.write_text(s)
print('route client dipasang')
PY
    else
        echo "route client sudah ada, dilewati"
    fi
}

patch_route_admin() {
    if ! grep -q "AnnouncementController" routes/admin.php; then
        python3 - <<'PY'
import pathlib
p = pathlib.Path('routes/admin.php')
s = p.read_text()
block = """
Route::group(['prefix' => 'announcements'], function () {
    Route::get('/', [Admin\\AnnouncementController::class, 'index'])->name('admin.announcements');
    Route::post('/', [Admin\\AnnouncementController::class, 'store']);
    Route::post('/{announcement}/duplicate', [Admin\\AnnouncementController::class, 'duplicate'])->name('admin.announcements.duplicate');
    Route::post('/{announcement}', [Admin\\AnnouncementController::class, 'update'])->name('admin.announcements.update');
});
"""
s = s.rstrip() + '\n' + block
p.write_text(s)
print('route admin dipasang')
PY
    else
        echo "route admin sudah ada, dilewati"
    fi
}

patch_schedule() {
    if ! grep -q "RecheckServerDomainsCommand" app/Console/Kernel.php; then
        python3 - <<'PY'
import pathlib
p = pathlib.Path('app/Console/Kernel.php')
s = p.read_text()
if 'use Pterodactyl\\Console\\Commands\\Domain\\RecheckServerDomainsCommand;' not in s:
    s = s.replace('use Illuminate\\Console\\Scheduling\\Schedule;', 'use Illuminate\\Console\\Scheduling\\Schedule;\nuse Pterodactyl\\Console\\Commands\\Domain\\RecheckServerDomainsCommand;')
anchor = '$schedule->command(PruneOrphanedBackupsCommand::class)->everyThirtyMinutes();'
add = anchor + "\n        $schedule->command(RecheckServerDomainsCommand::class)\n            ->everyThirtyMinutes();"
assert anchor in s, 'anchor schedule tidak ketemu'
s = s.replace(anchor, add)
p.write_text(s)
print('jadwal recheck dipasang')
PY
    else
        echo "jadwal recheck sudah ada, dilewati"
    fi
}

patch_route_client
patch_route_admin
patch_schedule
echo "patch backend selesai"
