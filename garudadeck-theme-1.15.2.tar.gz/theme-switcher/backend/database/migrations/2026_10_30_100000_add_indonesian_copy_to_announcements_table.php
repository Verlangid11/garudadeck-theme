<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class () extends Migration {
    public function up(): void
    {
        Schema::table('announcements', function (Blueprint $table) {
            // Optional Indonesian copy: when filled, an id account reads this
            // instead of the default title and message. Null means fall back
            // to the default text, so old rows keep working untouched.
            $table->string('title_id', 80)->nullable()->after('title');
            $table->text('message_id')->nullable()->after('message');
        });
    }

    public function down(): void
    {
        Schema::table('announcements', function (Blueprint $table) {
            $table->dropColumn(['title_id', 'message_id']);
        });
    }
};
