<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class () extends Migration {
    /**
     * One custom join domain per server.
     *
     * The panel only manages the link between a server and a hostname: the
     * owner points their domain at the node IP with an A record, proves
     * ownership with a TXT record, and the panel verifies both with real DNS
     * lookups before treating the hostname as this server's join address.
     * The panel never creates DNS records and never proxies traffic; anything
     * the owner did not type themselves is not trusted.
     *
     * `status` is pending | verified | failed, so a domain that stops
     * resolving shows a failure on the page instead of a stale address.
     */
    public function up(): void
    {
        Schema::create('server_custom_domains', function (Blueprint $table) {
            $table->id();
            $table->unsignedInteger('server_id');
            $table->string('domain', 253);
            $table->string('token', 64);
            // pending | verified | failed
            $table->string('status', 16)->default('pending');
            $table->text('last_error')->nullable();
            $table->dateTime('verified_at')->nullable();
            $table->dateTime('last_checked_at')->nullable();
            $table->timestamps();

            $table->unique('server_id');
            $table->unique('domain');
            $table->foreign('server_id')->references('id')->on('servers')->onDelete('cascade');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('server_custom_domains');
    }
};
