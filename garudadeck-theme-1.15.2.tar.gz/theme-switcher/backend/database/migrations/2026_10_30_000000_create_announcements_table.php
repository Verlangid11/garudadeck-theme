<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

return new class () extends Migration {
    public function up(): void
    {
        Schema::create('announcements', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('message');
            // info | success | warning | danger, maps to the client banner tone.
            $table->string('tone', 16)->default('info');
            // Theme name the banner font follows: sans | mono | display.
            $table->string('font', 16)->default('sans');
            // Hex colors stored without alpha, validated by the controller.
            $table->string('accent_color', 7)->default('#2563eb');
            $table->string('background_color', 7)->default('#0f172a');
            $table->string('text_color', 7)->default('#f8fafc');
            $table->unsignedInteger('sort')->default(0);
            $table->boolean('is_active')->default(true);
            // Null means no schedule: show immediately until turned off.
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('announcements');
    }
};
