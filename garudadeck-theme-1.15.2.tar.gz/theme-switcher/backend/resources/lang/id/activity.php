<?php

/**
 * Translation strings for activity log events. Keys match the part of the
 * event name in front of the colon (:), or the top level when there is none.
 */
return [
    'auth' => [
        'fail' => 'Gagal masuk',
        'success' => 'Masuk ke panel',
        'password-reset' => 'Password diatur ulang',
        'reset-password' => 'Meminta pengaturan ulang password',
        'checkpoint' => 'Autentikasi dua faktor diminta',
        'recovery-token' => 'Memakai token pemulihan dua faktor',
        'token' => 'Menyelesaikan tantangan dua faktor',
        'ip-blocked' => 'Memblokir permintaan dari alamat IP yang tidak terdaftar untuk :identifier',
        'sftp' => [
            'fail' => 'Gagal masuk SFTP',
        ],
    ],
    'user' => [
        'user' => [
            'create' => 'Membuat pengguna baru :email',
        ],
        'account' => [
            'email-changed' => 'Mengubah email dari :old menjadi :new',
            'password-changed' => 'Mengubah password',
        ],
        'api-key' => [
            'create' => 'Membuat API key baru :identifier',
            'delete' => 'Menghapus API key :identifier',
        ],
        'ssh-key' => [
            'create' => 'Menambahkan SSH key :fingerprint ke akun',
            'delete' => 'Menghapus SSH key :fingerprint dari akun',
        ],
        'two-factor' => [
            'create' => 'Mengaktifkan autentikasi dua faktor',
            'delete' => 'Menonaktifkan autentikasi dua faktor',
        ],
    ],
    'server' => [
        'reinstall' => 'Memasang ulang server',
        'console' => [
            'command' => 'Menjalankan ":command" di server',
        ],
        'power' => [
            'start' => 'Menyalakan server',
            'stop' => 'Mematikan server',
            'restart' => 'Memulai ulang server',
            'kill' => 'Menghentikan paksa proses server',
        ],
        'backup' => [
            'download' => 'Mengunduh backup :name',
            'delete' => 'Menghapus backup :name',
            'restore' => 'Memulihkan backup :name (file yang dihapus: :truncate)',
            'restore-complete' => 'Menyelesaikan pemulihan backup :name',
            'restore-failed' => 'Gagal menyelesaikan pemulihan backup :name',
            'start' => 'Memulai backup baru :name',
            'complete' => 'Menandai backup :name selesai',
            'fail' => 'Menandai backup :name gagal',
            'lock' => 'Mengunci backup :name',
            'unlock' => 'Membuka kunci backup :name',
        ],
        'database' => [
            'create' => 'Membuat database baru :name',
            'rotate-password' => 'Mengganti password database :name',
            'delete' => 'Menghapus database :name',
        ],
        'file' => [
            'compress_one' => 'Mengompres :directory:files.0',
            'compress_other' => 'Mengompres :count file di :directory',
            'read' => 'Melihat isi :file',
            'copy' => 'Membuat salinan :file',
            'create-directory' => 'Membuat direktori :directory:name',
            'decompress' => 'Mengekstrak :files di :directory',
            'delete_one' => 'Menghapus :directory:files.0',
            'delete_other' => 'Menghapus :count file di :directory',
            'download' => 'Mengunduh :file',
            'pull' => 'Mengunduh file dari :url ke :directory',
            'rename_one' => 'Mengganti nama :directory:files.0.from menjadi :directory:files.0.to',
            'rename_other' => 'Mengganti nama :count file di :directory',
            'write' => 'Menulis konten baru ke :file',
            'upload' => 'Memulai unggahan file',
            'uploaded' => 'Mengunggah :directory:file',
        ],
        'sftp' => [
            'denied' => 'Memblokir akses SFTP karena izin',
            'create_one' => 'Membuat :files.0',
            'create_other' => 'Membuat :count file baru',
            'write_one' => 'Mengubah isi :files.0',
            'write_other' => 'Mengubah isi :count file',
            'delete_one' => 'Menghapus :files.0',
            'delete_other' => 'Menghapus :count file',
            'create-directory_one' => 'Membuat direktori :files.0',
            'create-directory_other' => 'Membuat :count direktori',
            'rename_one' => 'Mengganti nama :files.0.from menjadi :files.0.to',
            'rename_other' => 'Mengganti nama atau memindahkan :count file',
        ],
        'allocation' => [
            'create' => 'Menambahkan :allocation ke server',
            'notes' => 'Mengubah catatan untuk :allocation dari ":old" menjadi ":new"',
            'primary' => 'Menjadikan :allocation alokasi utama server',
            'delete' => 'Menghapus alokasi :allocation',
        ],
        'domain' => [
            'update' => 'Mengubah domain join kustom dari :old menjadi :new',
            'verify' => 'Memeriksa domain join kustom :domain (:status)',
            'expired' => 'Domain join kustom :domain kedaluwarsa: :error',
            'delete' => 'Menghapus domain join kustom :domain',
        ],
        'schedule' => [
            'create' => 'Membuat schedule :name',
            'update' => 'Memperbarui schedule :name',
            'execute' => 'Menjalankan schedule :name secara manual',
            'delete' => 'Menghapus schedule :name',
        ],
        'task' => [
            'create' => 'Membuat task ":action" baru untuk schedule :name',
            'update' => 'Memperbarui task ":action" untuk schedule :name',
            'delete' => 'Menghapus task untuk schedule :name',
        ],
        'settings' => [
            'rename' => 'Mengganti nama server dari :old menjadi :new',
            'description' => 'Mengubah deskripsi server dari :old menjadi :new',
        ],
        'startup' => [
            'edit' => 'Mengubah variabel :variable dari ":old" menjadi ":new"',
            'image' => 'Memperbarui Docker Image server dari :old menjadi :new',
        ],
        'subuser' => [
            'create' => 'Menambahkan :email sebagai subuser',
            'update' => 'Memperbarui izin subuser :email',
            'delete' => 'Menghapus :email dari subuser',
        ],
    ],
];
