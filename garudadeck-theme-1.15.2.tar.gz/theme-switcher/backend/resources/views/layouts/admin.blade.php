<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}" data-admin-theme="light">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>{{ config('app.name', 'Pterodactyl') }} - @yield('title')</title>
        <meta content="width=device-width, initial-scale=1" name="viewport">
        <meta name="_token" content="{{ csrf_token() }}">
        {{-- Admin surfaces are private. This is a belt-and-braces tag on top of
             the robots.txt rules that already disallow /admin. --}}
        <meta name="robots" content="noindex, nofollow">

        <link rel="apple-touch-icon" sizes="180x180" href="/favicons/apple-touch-icon.png">
        <link rel="icon" type="image/png" href="/favicons/favicon-32x32.png" sizes="32x32">
        <link rel="icon" type="image/png" href="/favicons/favicon-16x16.png" sizes="16x16">
        <link rel="manifest" href="/favicons/manifest.json">
        <link rel="shortcut icon" href="/favicons/favicon.ico">
        <meta name="theme-color" content="#F4F6F8">

        <script>
            // Applied before first paint so a light-mode admin never flashes
            // dark (or the reverse) while the rest of the head parses.
            (function () {
                try {
                    var mode = localStorage.getItem('pterodactyl:admin-theme');
                    document.documentElement.setAttribute('data-admin-theme', mode === 'dark' ? 'dark' : 'light');
                } catch (e) {}
            })();
        </script>

        @include('layouts.scripts')

        {{-- Type is part of the console's identity: Inter Tight carries the
             structure, Inter the prose, JetBrains Mono the data. If the
             network is unavailable the stack falls back to system faces.

             Loaded non-blocking on purpose. A plain stylesheet link in <head>
             holds up first paint until the request finishes, so on a network
             where fonts.googleapis.com is slow or filtered the whole admin
             page sits blank waiting on a third party. media="print" makes the
             browser fetch it without blocking, and onload flips it to screen;
             if it never arrives the fallback stack is already on screen. --}}
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap"
            media="print"
            onload="this.media='all'"
        >
        <noscript>
            <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter+Tight:wght@500;600;700&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap">
        </noscript>

        @section('scripts')
            {!! Theme::css('vendor/select2/select2.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/bootstrap/bootstrap.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/adminlte/admin.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/sweetalert/sweetalert.min.css?t={cache-version}') !!}
            {!! Theme::css('vendor/animate/animate.min.css?t={cache-version}') !!}
            {{-- `css/pterodactyl.css` is the client theme. It paints a dark
                 palette with `!important` on boxes, alerts, buttons, tables and
                 form fields, so loading it here meant every admin rule was
                 fighting a stylesheet that sometimes won. The admin shell now
                 owns its components outright; see section 13 of admin-panel.css
                 for the vendor widgets that still need a skin. --}}
            {{-- The admin stylesheet is edited in place, so its cache key is the
                 file's own mtime rather than a build-time placeholder. --}}
            {!! Theme::css('css/admin-panel.css?t=' . filemtime(public_path('themes/pterodactyl/css/admin-panel.css'))) !!}
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        @show
    </head>
    <body class="ptero-admin">
        {{-- Target is the content area, not #ptero-main: that wrapper also
             holds the topbar, so landing on it left the skip link user on the
             header they were trying to skip. --}}
        <a href="#ptero-content" class="ptero-skip">{{ __('Lewati ke konten') }}</a>

        <div class="ptero-shell">
            <div class="ptero-backdrop" id="ptero-backdrop" hidden></div>

            <aside class="ptero-sidebar" id="ptero-sidebar" aria-label="{{ __('Navigasi admin') }}">
                <div class="ptero-brand">
                    <a href="{{ route('admin.index') }}">
                        <span class="ptero-brand-mark" aria-hidden="true">{{ strtoupper(substr(config('app.name', 'P'), 0, 2)) }}</span>
                        <span class="ptero-brand-text">
                            <strong>{{ config('app.name', 'Pterodactyl') }}</strong>
                            <small>{{ __('Panel admin') }}</small>
                        </span>
                    </a>
                </div>

                <div class="ptero-sidebar-tools">
                    {{-- Collapsing only has a meaning while the sidebar is a
                         fixed column. On a phone the sidebar is an off-canvas
                         drawer that the X already closes, so this button did
                         nothing visible there and still wrote the desktop
                         preference, silently rearranging the admin panel on
                         the next laptop visit. --}}
                    <button type="button" class="ptero-icon-btn ptero-desktop-only" id="ptero-rail-btn" aria-label="{{ __('Ringkas sidebar') }}" title="{{ __('Ringkas sidebar') }}">
                        <i class="fa fa-align-left"></i>
                    </button>
                    <button type="button" class="ptero-icon-btn ptero-mobile-only" id="ptero-close-btn" aria-label="{{ __('Tutup navigasi') }}">
                        <i class="fa fa-times"></i>
                    </button>
                    <span class="ptero-sidebar-version">v{{ $appVersion }}</span>
                </div>

                <nav class="ptero-nav">
                    <div class="ptero-nav-group">{{ __('Ringkasan') }}</div>
                    <a href="{{ route('admin.index') }}" class="{{ Route::currentRouteName() === 'admin.index' ? 'active' : '' }}" title="{{ __('Ringkasan') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-home"></i></span>
                        <span class="ptero-nav-label">{{ __('Ringkasan') }}</span>
                        @if (($adminNav['attention'] ?? 0) > 0)<span class="ptero-nav-count warn">{{ $adminNav['attention'] }}</span>@endif
                    </a>

                    <div class="ptero-nav-group">{{ __('Manajemen') }}</div>
                    <a href="{{ route('admin.servers') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.servers') ? 'active' : '' }}" title="{{ __('Server') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-server"></i></span>
                        <span class="ptero-nav-label">{{ __('Server') }}</span>
                        <span class="ptero-nav-count">{{ $adminNav['servers'] ?? 0 }}</span>
                    </a>
                    <a href="{{ route('admin.users') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.users') ? 'active' : '' }}" title="{{ __('User') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-users"></i></span>
                        <span class="ptero-nav-label">{{ __('User') }}</span>
                        <span class="ptero-nav-count">{{ $adminNav['users'] ?? 0 }}</span>
                    </a>
                    <a href="{{ route('admin.nodes') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.nodes') ? 'active' : '' }}" title="{{ __('Node') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-sitemap"></i></span>
                        <span class="ptero-nav-label">{{ __('Node') }}</span>
                        <span class="ptero-nav-count">{{ $adminNav['nodes'] ?? 0 }}</span>
                    </a>
                    <a href="{{ route('admin.locations') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.locations') ? 'active' : '' }}" title="{{ __('Lokasi') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-globe"></i></span>
                        <span class="ptero-nav-label">{{ __('Lokasi') }}</span>
                    </a>

                    <div class="ptero-nav-group">{{ __('Layanan') }}</div>
                    <a href="{{ route('admin.nests') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.nests') ? 'active' : '' }}" title="{{ __('Nest') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-th-large"></i></span>
                        <span class="ptero-nav-label">{{ __('Nest') }}</span>
                    </a>
                    <a href="{{ route('admin.mounts') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.mounts') ? 'active' : '' }}" title="{{ __('Mounts') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-magic"></i></span>
                        <span class="ptero-nav-label">{{ __('Mount') }}</span>
                    </a>
                    <a href="{{ route('admin.databases') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.databases') ? 'active' : '' }}" title="{{ __('Host database') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-database"></i></span>
                        <span class="ptero-nav-label">{{ __('Host database') }}</span>
                    </a>

                    <div class="ptero-nav-group">{{ __('Konten') }}</div>
                    <a href="{{ route('admin.announcements') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.announcements') ? 'active' : '' }}" title="{{ __('Pengumuman') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-bullhorn"></i></span>
                        <span class="ptero-nav-label">{{ __('Pengumuman') }}</span>
                    </a>
                    <a href="{{ route('admin.dashboard-links') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.dashboard-links') ? 'active' : '' }}" title="{{ __('Link dashboard') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-link"></i></span>
                        <span class="ptero-nav-label">{{ __('Link dashboard') }}</span>
                    </a>
                    <a href="{{ route('admin.settings.seo') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.settings.seo') ? 'active' : '' }}" title="{{ __('SEO') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-search"></i></span>
                        <span class="ptero-nav-label">{{ __('SEO') }}</span>
                    </a>

                    <div class="ptero-nav-group">{{ __('Sistem') }}</div>
                    <a href="{{ route('admin.settings') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.settings') && !starts_with(Route::currentRouteName(), 'admin.settings.seo') ? 'active' : '' }}" title="{{ __('Pengaturan') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-wrench"></i></span>
                        <span class="ptero-nav-label">{{ __('Pengaturan') }}</span>
                    </a>
                    <a href="{{ route('admin.api.index') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.api') ? 'active' : '' }}" title="{{ __('Application API') }}">
                        <span class="ptero-nav-icon"><i class="fa fa-gamepad"></i></span>
                        <span class="ptero-nav-label">{{ __('Application API') }}</span>
                    </a>
                </nav>

                <div class="ptero-sidebar-footer">
                    <a href="{{ route('account') }}" class="ptero-sidebar-user">
                        <img src="https://www.gravatar.com/avatar/{{ md5(strtolower(Auth::user()->email)) }}?s=80&d=mp" alt="">
                        <span class="ptero-sidebar-user-text">
                            <strong>{{ Auth::user()->name_first ?: Auth::user()->username }}</strong>
                            <small>{{ Auth::user()->root_admin ? 'Administrator' : 'Akun saya' }}</small>
                        </span>
                        <i class="fa fa-angle-right" aria-hidden="true"></i>
                    </a>
                    <a href="{{ route('auth.logout') }}" class="ptero-icon-btn" title="{{ __('Keluar') }}" aria-label="{{ __('Keluar') }}">
                        <i class="fa fa-sign-out"></i>
                    </a>
                </div>
            </aside>

            <div class="ptero-main" id="ptero-main">
                <header class="ptero-topbar">
                    <button type="button" class="ptero-icon-btn ptero-mobile-only" id="ptero-menu-btn" aria-label="{{ __('Buka navigasi') }}" aria-controls="ptero-sidebar" aria-expanded="false">
                        <i class="fa fa-bars"></i>
                    </button>
                    <button type="button" class="ptero-icon-btn ptero-desktop-only" id="ptero-rail-toggle" aria-label="{{ __('Ringkas sidebar') }}" title="{{ __('Ringkas sidebar') }}">
                        <i class="fa fa-columns"></i>
                    </button>

                    <nav class="ptero-crumbs" aria-label="{{ __('Breadcrumb') }}">
                        <a href="{{ route('admin.index') }}">{{ __('Admin') }}</a>
                        <span aria-hidden="true">/</span>
                        <span aria-current="page">@yield('title')</span>
                    </nav>

                    <div class="ptero-topbar-actions">
                        <button type="button" class="ptero-command-trigger" id="ptero-palette-btn" aria-label="{{ __('Cari cepat') }}" title="{{ __('Cari cepat (Ctrl K)') }}">
                            <i class="fa fa-search" aria-hidden="true"></i>
                            <span>{{ __('Cari server, user, node') }}</span>
                            <kbd>{{ __('Ctrl K') }}</kbd>
                        </button>
                        <button type="button" class="ptero-icon-btn ptero-mobile-only" id="ptero-search-mobile" aria-label="{{ __('Cari') }}">
                            <i class="fa fa-search"></i>
                        </button>
                        @php
                            $adminLocale = strtolower(Auth::user()->language ?? config('app.locale'));
                            $adminLanguageList = $adminLanguages ?? [];
                        @endphp
                        <form action="{{ route('admin.language') }}" method="POST" class="ptero-lang" data-ptero-lang>
                            @csrf
                            {{-- The menu is rendered markup, not a native <select>:
                                 a native option list cannot carry the mono code
                                 column or the check mark, and it ignores the
                                 admin palette on every platform but Windows.
                                 The hidden input is what actually posts. --}}
                            <input type="hidden" name="language" value="{{ $adminLocale }}" data-ptero-lang-input>
                            <button type="button" class="ptero-lang-trigger" data-ptero-lang-trigger
                                    aria-haspopup="listbox" aria-expanded="false"
                                    aria-label="{{ __('Bahasa panel') }}" title="{{ __('Bahasa panel') }}">
                                <i class="fa fa-globe" aria-hidden="true"></i>
                                <span class="ptero-lang-value" data-ptero-lang-value>{{ $adminLanguageList[$adminLocale] ?? strtoupper($adminLocale) }}</span>
                                <i class="fa fa-angle-down ptero-lang-caret" aria-hidden="true"></i>
                            </button>
                            <div class="ptero-lang-menu" role="listbox" aria-label="{{ __('Bahasa panel') }}" data-ptero-lang-menu hidden>
                                @foreach ($adminLanguageList as $code => $label)
                                    <button type="button" class="ptero-lang-option" role="option"
                                            data-ptero-lang-option data-value="{{ $code }}"
                                            aria-selected="{{ $adminLocale === $code ? 'true' : 'false' }}">
                                        <i class="fa fa-check" aria-hidden="true"></i>
                                        <span class="ptero-lang-name">{{ $label }}</span>
                                        <span class="ptero-lang-code">{{ strtoupper($code) }}</span>
                                    </button>
                                @endforeach
                            </div>
                            <noscript>
                                {{-- With scripting off the hidden input above is
                                     still posted, but it comes first, so the
                                     browser sends the select value last and the
                                     server keeps that one. --}}
                                <select name="language" id="pteroLang" aria-label="{{ __('Bahasa panel') }}">
                                    @foreach ($adminLanguageList as $code => $label)
                                        <option value="{{ $code }}" @selected($adminLocale === $code)>{{ $label }}</option>
                                    @endforeach
                                </select>
                                <button type="submit" class="ptero-icon-btn" aria-label="{{ __('Simpan bahasa') }}"><i class="fa fa-check"></i></button>
                            </noscript>
                        </form>
                        <button type="button" class="ptero-icon-btn" id="ptero-theme-toggle" aria-label="{{ __('Ganti tema') }}" title="{{ __('Ganti tema') }}">
                            <i class="fa fa-moon-o" id="ptero-theme-icon"></i>
                        </button>
                        <a href="{{ route('index') }}" class="ptero-icon-btn ptero-desktop-only" title="{{ __('Lihat panel client') }}" aria-label="{{ __('Lihat panel client') }}">
                            <i class="fa fa-external-link"></i>
                        </a>
                        <a href="{{ route('auth.logout') }}" class="ptero-icon-btn" id="logoutButton" title="{{ __('Keluar') }}" aria-label="{{ __('Keluar') }}">
                            <i class="fa fa-sign-out"></i>
                        </a>
                    </div>
                </header>

                <main class="ptero-content" id="ptero-content" tabindex="-1">
                    @hasSection('content-header')
                        <div class="ptero-pagehead">
                            @yield('content-header')
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="ptero-alert danger" role="alert">{{ __('Ada data yang belum lolos validasi.') }}                            <ul>
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @foreach (Alert::getMessages() as $type => $messages)
                        @foreach ($messages as $message)
                            <div class="ptero-alert {{ $type === 'error' ? 'danger' : $type }}" role="status">
                                {{ $message }}
                            </div>
                        @endforeach
                    @endforeach

                    @yield('content')
                </main>

                <footer class="ptero-footer">
                    <span>{{ config('app.name') }} &copy; {{ date('Y') }}</span>
                    <span>
                        <i class="fa fa-{{ $appIsGit ? 'git-square' : 'code-fork' }}"></i>
                        {{ $appVersion }}
                    </span>
                </footer>
            </div>
        </div>

        <nav class="ptero-mobilebar" aria-label="{{ __('Navigasi cepat') }}">
            <a href="{{ route('admin.index') }}" class="{{ Route::currentRouteName() === 'admin.index' ? 'active' : '' }}">
                <i class="fa fa-home"></i><span>{{ __('Ringkasan') }}</span>
            </a>
            <a href="{{ route('admin.servers') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.servers') ? 'active' : '' }}">
                <i class="fa fa-server"></i><span>{{ __('Server') }}</span>
            </a>
            <a href="{{ route('admin.users') }}" class="{{ starts_with(Route::currentRouteName(), 'admin.users') ? 'active' : '' }}">
                <i class="fa fa-users"></i><span>{{ __('User') }}</span>
            </a>
            <button type="button" id="ptero-menu-bottom" aria-controls="ptero-sidebar">
                <i class="fa fa-bars"></i><span>{{ __('Menu') }}</span>
            </button>
        </nav>

        <div class="ptero-palette" id="ptero-palette" hidden>
            <div class="ptero-palette-backdrop" data-palette-close></div>
            <div class="ptero-palette-panel" role="dialog" aria-modal="true" aria-labelledby="ptero-palette-label" aria-describedby="ptero-palette-title">
                {{-- The dialog and the search box both used to be named by the
                     hint paragraph, so the box was announced as "type at least
                     two characters" instead of "Quick search". The hint is a
                     description, not a name. --}}
                <h2 id="ptero-palette-label" class="sr-only">{{ __('Cari cepat') }}</h2>
                <div class="ptero-palette-input">
                    <i class="fa fa-search" aria-hidden="true"></i>
                    <input id="ptero-palette-input" type="search" placeholder="{{ __('Cari server, user, atau node') }}" autocomplete="off"
                        role="combobox" aria-expanded="false" aria-autocomplete="list" aria-controls="ptero-palette-results"
                        aria-labelledby="ptero-palette-label" aria-describedby="ptero-palette-title">
                    <kbd>{{ __('Esc') }}</kbd>
                </div>
                <p id="ptero-palette-title" class="ptero-palette-hint">{{ __('Ketik minimal dua karakter. Panah untuk memilih, Enter untuk membuka.') }}</p>
                <div class="ptero-palette-results" id="ptero-palette-results" role="listbox" aria-labelledby="ptero-palette-label"></div>
                {{-- Results appear and vanish as you type. Without a live
                     region a screen reader user typed into silence and had no
                     way to know the list had changed. --}}
                <p id="ptero-palette-status" class="sr-only" role="status" aria-live="polite"></p>
            </div>
        </div>

        @section('footer-scripts')
            <script src="/js/keyboard.polyfill.js" type="application/javascript"></script>
            <script>keyboardeventKeyPolyfill.polyfill();</script>

            {!! Theme::js('vendor/jquery/jquery.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/sweetalert/sweetalert.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap/bootstrap.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/bootstrap-notify/bootstrap-notify.min.js?t={cache-version}') !!}
            {!! Theme::js('vendor/select2/select2.full.min.js?t={cache-version}') !!}
            {!! Theme::js('js/admin/functions.js?t={cache-version}') !!}
            <script src="/js/autocomplete.js" type="application/javascript"></script>

            <script>
                (function () {
                    var root = document.documentElement;
                    var key = 'pterodactyl:admin-theme';
                    var toggle = document.getElementById('ptero-theme-toggle');
                    var icon = document.getElementById('ptero-theme-icon');

                    function apply(mode) {
                        root.setAttribute('data-admin-theme', mode);
                        if (icon) {
                            // The icon shows the mode you would switch to, not
                            // the one you are in: moon while light, sun while dark.
                            icon.className = mode === 'light' ? 'fa fa-moon-o' : 'fa fa-sun-o';
                        }
                        if (toggle) {
                            // A toggle that only changes its glyph leaves the
                            // current mode unreadable to anyone who cannot see
                            // that glyph. `aria-pressed` states it outright.
                            toggle.setAttribute('aria-pressed', mode === 'dark' ? 'true' : 'false');
                        }
                        var chrome = document.querySelector('meta[name="theme-color"]');
                        if (chrome) {
                            chrome.setAttribute('content', mode === 'light' ? '#F4F6F8' : '#0E1114');
                        }
                        try {
                            localStorage.setItem(key, mode);
                        } catch (e) {}
                    }

                    apply(root.getAttribute('data-admin-theme') || 'light');

                    if (toggle) {
                        toggle.addEventListener('click', function () {
                            apply(root.getAttribute('data-admin-theme') === 'light' ? 'dark' : 'light');
                        });
                    }

                    // Language menu. Submitting on change keeps the old
                    // one-roundtrip behaviour of the native select; the menu
                    // only changes how the choice is presented.
                    var langForm = document.querySelector('[data-ptero-lang]');
                    if (langForm) {
                        var langInput = langForm.querySelector('[data-ptero-lang-input]');
                        var langTrigger = langForm.querySelector('[data-ptero-lang-trigger]');
                        var langMenu = langForm.querySelector('[data-ptero-lang-menu]');
                        var langValue = langForm.querySelector('[data-ptero-lang-value]');
                        var langOptions = Array.prototype.slice.call(
                            langForm.querySelectorAll('[data-ptero-lang-option]')
                        );

                        var setLangOpen = function (open) {
                            langMenu.hidden = !open;
                            langForm.toggleAttribute('data-open', open);
                            langTrigger.setAttribute('aria-expanded', open ? 'true' : 'false');
                        };

                        langTrigger.addEventListener('click', function () {
                            setLangOpen(langMenu.hidden);
                            if (!langMenu.hidden) {
                                var current = langOptions.filter(function (option) {
                                    return option.getAttribute('aria-selected') === 'true';
                                })[0];
                                (current || langOptions[0]).focus();
                            }
                        });

                        langOptions.forEach(function (option) {
                            option.addEventListener('click', function () {
                                var value = option.getAttribute('data-value');
                                if (value === langInput.value) {
                                    setLangOpen(false);
                                    langTrigger.focus();
                                    return;
                                }

                                langInput.value = value;
                                if (langValue) langValue.textContent = option.querySelector('.ptero-lang-name').textContent;
                                // Move the check mark before the request goes
                                // out: the page stays interactive while it is in
                                // flight, and a second click on the same row
                                // should be a no-op rather than another submit.
                                langOptions.forEach(function (row) {
                                    row.setAttribute('aria-selected', row === option ? 'true' : 'false');
                                });
                                setLangOpen(false);
                                langForm.submit();
                            });

                            // Arrow keys walk the list, Home/End jump to the
                            // ends, Escape closes and returns focus. Tab is
                            // left alone so it can still leave the menu.
                            option.addEventListener('keydown', function (event) {
                                var index = langOptions.indexOf(option);
                                var next = null;

                                if (event.key === 'ArrowDown') next = (index + 1) % langOptions.length;
                                else if (event.key === 'ArrowUp') next = (index - 1 + langOptions.length) % langOptions.length;
                                else if (event.key === 'Home') next = 0;
                                else if (event.key === 'End') next = langOptions.length - 1;
                                else if (event.key === 'Escape') {
                                    event.preventDefault();
                                    setLangOpen(false);
                                    langTrigger.focus();
                                    return;
                                } else if (event.key === 'Enter' || event.key === ' ') {
                                    event.preventDefault();
                                    option.click();
                                    return;
                                }

                                if (next !== null) {
                                    event.preventDefault();
                                    langOptions[next].focus();
                                }
                            });
                        });

                        document.addEventListener('mousedown', function (event) {
                            if (!langForm.contains(event.target)) setLangOpen(false);
                        });

                        document.addEventListener('keydown', function (event) {
                            if (event.key === 'Escape' && !langMenu.hidden) {
                                setLangOpen(false);
                                langTrigger.focus();
                            }
                        });
                    }

                    var sidebar = document.getElementById('ptero-sidebar');
                    var backdrop = document.getElementById('ptero-backdrop');
                    var menuBtn = document.getElementById('ptero-menu-btn');

                    function setMenu(open) {
                        if (!sidebar || !backdrop || !menuBtn) return;
                        sidebar.classList.toggle('open', open);
                        backdrop.hidden = !open;
                        menuBtn.setAttribute('aria-expanded', open ? 'true' : 'false');
                        // Locks the page behind the drawer; without it a swipe
                        // scrolls the content under the panel.
                        document.body.classList.toggle('ptero-drawer-open', open);
                    }

                    if (menuBtn) {
                        menuBtn.addEventListener('click', function () {
                            setMenu(!sidebar.classList.contains('open'));
                        });
                    }
                    if (backdrop) {
                        backdrop.addEventListener('click', function () {
                            setMenu(false);
                        });
                    }
                    if (sidebar) {
                        sidebar.querySelectorAll('a').forEach(function (link) {
                            link.addEventListener('click', function () {
                                if (window.innerWidth <= 991) setMenu(false);
                            });
                        });
                    }
                    var closeBtn = document.getElementById('ptero-close-btn');
                    if (closeBtn) closeBtn.addEventListener('click', function () { setMenu(false); });
                    var bottomMenu = document.getElementById('ptero-menu-bottom');
                    if (bottomMenu) bottomMenu.addEventListener('click', function () { setMenu(true); });

                    var railBtn = document.getElementById('ptero-rail-btn');
                    var railToggle = document.getElementById('ptero-rail-toggle');

                    // The button says what it will do, not what the sidebar is
                    // doing now. It used to read "Collapse sidebar" in both
                    // states, so once the rail was already collapsed the only
                    // control on screen announced the opposite of its action,
                    // and a screen reader user had no way to learn the state.
                    // `aria-expanded` carries that state on its own.
                    var railLabelOpen = @json(__('Ringkas sidebar'));
                    var railLabelClosed = @json(__('Bentangkan sidebar'));

                    function applyRail(collapsed) {
                        document.body.classList.toggle('ptero-rail', collapsed);
                        [railBtn, railToggle].forEach(function (btn) {
                            if (!btn) return;
                            var label = collapsed ? railLabelClosed : railLabelOpen;
                            btn.setAttribute('aria-label', label);
                            btn.setAttribute('title', label);
                            btn.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
                        });
                    }

                    function setRail(collapsed) {
                        applyRail(collapsed);
                        try { localStorage.setItem('pterodactyl:admin-rail', collapsed ? '1' : '0'); } catch (e) {}
                    }

                    // Run once for the state the page actually loaded in, not
                    // only when a preference was saved. Without this first call
                    // the fresh visit had no aria-expanded at all, so the
                    // attribute existed only after a click. It does not write
                    // storage, so merely loading the panel does not invent a
                    // preference the reader never expressed.
                    var savedRail = null;
                    try { savedRail = localStorage.getItem('pterodactyl:admin-rail'); } catch (e) {}
                    applyRail(savedRail === '1');
                    [railBtn, railToggle].forEach(function (btn) {
                        if (btn) btn.addEventListener('click', function () { setRail(!document.body.classList.contains('ptero-rail')); });
                    });

                    // The bottom bar is fixed, so it covers whatever scrolls
                    // under it. Hiding it on a downward gesture and bringing it
                    // back on an upward one keeps the last field readable
                    // without giving up the bar.
                    var bar = document.querySelector('.ptero-mobilebar');
                    var lastY = window.pageYOffset || 0;
                    var barTicking = false;

                    function syncBar() {
                        barTicking = false;
                        var y = window.pageYOffset || 0;
                        var delta = y - lastY;
                        if (Math.abs(delta) < 6) return;
                        lastY = y;
                        var atTop = y < 80;
                        var nearBottom = (y + window.innerHeight) >= (document.documentElement.scrollHeight - 40);
                        if (atTop || nearBottom) {
                            bar.classList.remove('is-hidden');
                        } else {
                            bar.classList.toggle('is-hidden', delta > 0);
                        }
                    }

                    if (bar) {
                        window.addEventListener('scroll', function () {
                            if (barTicking) return;
                            barTicking = true;
                            window.requestAnimationFrame(syncBar);
                        }, { passive: true });
                    }

                    var palette = document.getElementById('ptero-palette');
                    var paletteInput = document.getElementById('ptero-palette-input');
                    var paletteResults = document.getElementById('ptero-palette-results');
                    var paletteStatus = document.getElementById('ptero-palette-status');
                    var paletteTimer = null;
                    var paletteItems = [];
                    var paletteIndex = 0;
                    var paletteLast = null;

                    var paletteRequest = 0;

                    // The listbox is virtual: focus stays in the input and the
                    // highlighted row is named by `aria-activedescendant`, which
                    // is the only way a combobox can keep the caret while the
                    // reader follows the selection.
                    function setPaletteActive(index) {
                        paletteItems.forEach(function (item, i) {
                            var on = i === index;
                            item.classList.toggle('selected', on);
                            item.setAttribute('aria-selected', on ? 'true' : 'false');
                        });
                        if (paletteItems[index]) {
                            paletteInput.setAttribute('aria-activedescendant', paletteItems[index].id);
                        } else {
                            paletteInput.removeAttribute('aria-activedescendant');
                        }
                    }
                    function announcePalette(text) {
                        if (!paletteStatus) return;
                        // Repeating the same string would not re-announce, so the
                        // text is cleared first and written on the next tick.
                        paletteStatus.textContent = '';
                        window.setTimeout(function () { paletteStatus.textContent = text; }, 30);
                    }
                    function resetPalette() {
                        paletteItems = [];
                        paletteIndex = 0;
                        paletteResults.innerHTML = '';
                        paletteInput.setAttribute('aria-expanded', 'false');
                        paletteInput.removeAttribute('aria-activedescendant');
                    }
                    function closePalette() {
                        if (!palette) return;
                        palette.hidden = true;
                        document.body.classList.remove('ptero-palette-open');
                        if (paletteLast && paletteLast.focus) paletteLast.focus();
                    }
                    function openPalette() {
                        if (!palette) return;
                        paletteLast = document.activeElement;
                        palette.hidden = false;
                        document.body.classList.add('ptero-palette-open');
                        paletteInput.value = '';
                        resetPalette();
                        if (paletteStatus) paletteStatus.textContent = '';
                        paletteInput.focus();
                    }
                    function renderPalette(groups) {
                        paletteItems = [];
                        paletteResults.innerHTML = '';
                        var any = false;
                        var groupId = 0;
                        groups.forEach(function (group) {
                            if (!group.items || !group.items.length) return;
                            any = true;
                            var label = document.createElement('p');
                            label.className = 'ptero-palette-group';
                            label.id = 'ptero-palette-group-' + (++groupId);
                            label.textContent = group.label;
                            paletteResults.appendChild(label);
                            var list = document.createElement('div');
                            list.className = 'ptero-palette-group-list';
                            list.setAttribute('role', 'group');
                            list.setAttribute('aria-labelledby', label.id);
                            paletteResults.appendChild(list);
                            group.items.forEach(function (item) {
                                var a = document.createElement('a');
                                a.href = item.url;
                                a.className = 'ptero-palette-item';
                                a.id = 'ptero-palette-option-' + paletteItems.length;
                                a.setAttribute('role', 'option');
                                a.setAttribute('aria-selected', 'false');
                                a.innerHTML = '<strong></strong><span></span>';
                                a.querySelector('strong').textContent = item.label;
                                a.querySelector('span').textContent = item.meta || '';
                                list.appendChild(a);
                                paletteItems.push(a);
                            });
                        });
                        if (!any) {
                            paletteResults.innerHTML = '<p class="ptero-palette-empty">{{ __('Tidak ada hasil.') }}</p>';
                            paletteInput.setAttribute('aria-expanded', 'false');
                            paletteInput.removeAttribute('aria-activedescendant');
                            announcePalette(@json(__('Tidak ada hasil.')));
                        } else {
                            paletteIndex = 0;
                            paletteInput.setAttribute('aria-expanded', 'true');
                            setPaletteActive(0);
                            // The two forms come from the translation, not from
                            // this script: English needs "1 result" against
                            // "5 results", and a language without plural
                            // inflection simply stores the same string twice.
                            announcePalette(
                                (paletteItems.length === 1
                                    ? @json(trans_choice('%d hasil.', 1))
                                    : @json(trans_choice('%d hasil.', 2))
                                ).replace('%d', paletteItems.length)
                            );
                        }
                    }
                    function movePalette(step) {
                        if (!paletteItems.length) return;
                        paletteIndex = (paletteIndex + step + paletteItems.length) % paletteItems.length;
                        setPaletteActive(paletteIndex);
                        paletteItems[paletteIndex].scrollIntoView({ block: 'nearest' });
                        announcePalette(paletteItems[paletteIndex].innerText.replace(/\s+/g, ' ').trim());
                    }
                    var paletteBtn = document.getElementById('ptero-palette-btn');
                    var searchMobile = document.getElementById('ptero-search-mobile');
                    if (paletteBtn && /Mac|iPhone|iPad/.test(navigator.platform)) {
                        var kbd = paletteBtn.querySelector('kbd');
                        if (kbd) kbd.textContent = '⌘ K';
                    }
                    if (paletteBtn) paletteBtn.addEventListener('click', openPalette);
                    if (searchMobile) searchMobile.addEventListener('click', openPalette);
                    Array.prototype.forEach.call(document.querySelectorAll('[data-palette-close]'), function (el) {
                        el.addEventListener('click', closePalette);
                    });
                    if (paletteInput) {
                        paletteInput.addEventListener('input', function () {
                            clearTimeout(paletteTimer);
                            var term = paletteInput.value.trim();
                            if (term.length < 2) {
                                resetPalette();
                                return;
                            }
                            paletteTimer = setTimeout(function () {
                                var ticket = ++paletteRequest;
                                fetch('{{ route('admin.search.json') }}?q=' + encodeURIComponent(term), { headers: { Accept: 'application/json' } })
                                    .then(function (res) { return res.json(); })
                                    .then(function (data) {
                                        if (ticket !== paletteRequest) return;
                                        renderPalette(data.groups || []);
                                    })
                                    .catch(function () {
                                        if (ticket !== paletteRequest) return;
                                        resetPalette();
                                        paletteResults.innerHTML = '<p class="ptero-palette-empty">{{ __('Pencarian gagal.') }}</p>';
                                        announcePalette(@json(__('Pencarian gagal.')));
                                    });
                            }, 180);
                        });
                        paletteInput.addEventListener('keydown', function (e) {
                            if (e.key === 'ArrowDown') { e.preventDefault(); movePalette(1); }
                            if (e.key === 'ArrowUp') { e.preventDefault(); movePalette(-1); }
                            if (e.key === 'Home' && paletteItems.length) { e.preventDefault(); paletteIndex = 0; setPaletteActive(0); announcePalette(paletteItems[0].innerText.replace(/\s+/g, ' ').trim()); }
                            if (e.key === 'End' && paletteItems.length) { e.preventDefault(); paletteIndex = paletteItems.length - 1; setPaletteActive(paletteIndex); announcePalette(paletteItems[paletteIndex].innerText.replace(/\s+/g, ' ').trim()); }
                            if (e.key === 'Enter' && paletteItems[paletteIndex]) {
                                e.preventDefault();
                                window.location = paletteItems[paletteIndex].href;
                            }
                        });
                    }

                    // The panel declares aria-modal, which tells a screen reader
                    // the rest of the page is inert. Tab has to agree, or focus
                    // walks into the sidebar behind the backdrop while the
                    // reader still refuses to announce it. Cycling between the
                    // input and the result links keeps the two in step.
                    var palettePanel = palette ? palette.querySelector('.ptero-palette-panel') : null;
                    if (palettePanel) {
                        palettePanel.addEventListener('keydown', function (e) {
                            if (e.key !== 'Tab') return;

                            var focusables = [paletteInput].concat(
                                Array.prototype.slice.call(paletteResults.querySelectorAll('a[href]'))
                            ).filter(function (el) {
                                return el && el.getClientRects().length > 0;
                            });

                            if (!focusables.length) return;

                            var first = focusables[0];
                            var last = focusables[focusables.length - 1];
                            var active = document.activeElement;

                            if (e.shiftKey && (active === first || active === palettePanel)) {
                                e.preventDefault();
                                last.focus();
                            } else if (!e.shiftKey && active === last) {
                                e.preventDefault();
                                first.focus();
                            }
                        });
                    }

                    document.addEventListener('keydown', function (e) {
                        if (e.key === 'Escape') {
                            setMenu(false);
                            if (palette && !palette.hidden) closePalette();
                        }

                        var active = document.activeElement;
                        var typing = !!active && /^(INPUT|TEXTAREA|SELECT)$/.test(active.tagName);
                        var key = e.key || '';
                        if (!typing && (key === '/' || (key.toLowerCase() === 'k' && (e.metaKey || e.ctrlKey)))) {
                            e.preventDefault();
                            openPalette();
                        }
                    });

                    // Tables in the admin markup have no data-label attributes,
                    // so the header row is copied onto every cell once. The CSS
                    // only reads the labels below 768px, where each row becomes
                    // a card instead of a horizontally scrolling desktop table.
                    function stackTables() {
                        var tables = document.querySelectorAll('.ptero-content table');
                        Array.prototype.forEach.call(tables, function (table) {
                            if (table.dataset.stacked === '1') return;
                            table.dataset.stacked = '1';

                            var headers = [];
                            var headRow = table.querySelector('thead tr');
                            if (!headRow) {
                                var rows = table.querySelectorAll('tr');
                                for (var i = 0; i < rows.length; i++) {
                                    if (rows[i].children.length && rows[i].children[0].tagName === 'TH') {
                                        headRow = rows[i];
                                        break;
                                    }
                                }
                            }
                            if (!headRow) {
                                // Definition tables (label / value pairs) have no
                                // header to copy, so they get a fixed two-column
                                // grid instead of unlabelled cards.
                                table.classList.add('ptero-table-kv');
                                return;
                            }

                            Array.prototype.forEach.call(headRow.children, function (cell) {
                                headers.push((cell.textContent || '').replace(/\s+/g, ' ').trim());
                            });

                            // Some legacy tables put the header row inside tbody
                            // instead of thead; it still has to disappear.
                            if (headRow.parentNode && headRow.parentNode.tagName === 'TBODY') {
                                headRow.classList.add('ptero-stack-head');
                            }

                            Array.prototype.forEach.call(table.querySelectorAll('tbody tr'), function (row) {
                                if (row.classList.contains('ptero-stack-head')) return;

                                var cells = Array.prototype.filter.call(row.children, function (cell) {
                                    return cell.tagName === 'TD';
                                });

                                cells.forEach(function (cell, index) {
                                    var label = headers[index] || '';
                                    cell.setAttribute('data-label', label.length > 28 ? label.slice(0, 27) + '…' : label);
                                });

                                // The card headline is the cell that names the row:
                                // the first readable link, else the longest text. Using
                                // the first column blindly turned IDs into headlines.
                                var primary = cells.find(function (cell) {
                                    var link = cell.querySelector('a');
                                    return link && (link.textContent || '').trim().length >= 4;
                                });

                                if (!primary) {
                                    primary = cells.reduce(function (best, cell) {
                                        var length = (cell.textContent || '').trim().length;
                                        return !best || length > best.length ? { cell: cell, length: length } : best;
                                    }, null);
                                    primary = primary && primary.cell;
                                }

                                if (primary) primary.setAttribute('data-primary', '1');
                            });

                            table.classList.add('ptero-table-stacked');
                        });
                    }

                    stackTables();
                })();
            </script>

            <script>
                // The content column carries an opacity animation, so it is a
                // stacking context: a modal opened inside it paints below the
                // sticky topbar and the fixed mobile bar. On a phone that put
                // the confirm button under the bar, and the dialog looked like
                // it never opened. Moving it to <body> when it opens takes it
                // out of every one of those layers.
                $(document).on('show.bs.modal', '.modal', function () {
                    if (this.parentNode !== document.body) {
                        document.body.appendChild(this);
                    }
                });

                // Bootstrap keeps the dialog at the top of a reopened modal;
                // after a long form was scrolled the next one opened halfway
                // down its own content.
                $(document).on('shown.bs.modal', '.modal', function () {
                    this.scrollTop = 0;
                });
            </script>

            @if(Auth::user()->root_admin)
                <script>
                    $('#logoutButton').on('click', function (event) {
                        event.preventDefault();

                        swal({
                            title: '{{ __('Keluar dari panel?') }}',
                            type: 'warning',
                            showCancelButton: true,
                            confirmButtonColor: '#d9534f',
                            cancelButtonColor: '#6b7280',
                            confirmButtonText: '{{ __('Keluar') }}',
                            cancelButtonText: '{{ __('Batal') }}'
                        }, function () {
                            $.ajax({
                                type: 'POST',
                                url: '{{ route('auth.logout') }}',
                                data: {
                                    _token: '{{ csrf_token() }}'
                                },complete: function () {
                                    window.location.href = '{{route('auth.login')}}';
                                }
                            });
                        });
                    });
                </script>
            @endif

            <script>
                $(function () {
                    $('[data-toggle="tooltip"]').tooltip();
                })
            </script>
        @show
    </body>
</html>
