@extends('layouts.admin')

@section('title')
    {{ __('Pengumuman') }}
@endsection

@section('content-header')
    <h1>{{ __('Pengumuman') }}<small>{{ __('Banner dinamis yang tampil di dashboard dan konsol client.') }}</small></h1>
    <ol class="breadcrumb">
        <li><a href="{{ route('admin.index') }}">{{ __('Admin') }}</a></li>
        <li class="active">{{ __('Pengumuman') }}</li>
    </ol>
@endsection

@section('content')
@php
    // Relative luminance per WCAG: warn the admin before a light-on-light or
    // dark-on-dark pair ships, because the client banner renders the exact
    // same pair on dashboard and console.
    $luminance = function ($hex) {
        $hex = ltrim((string) $hex, '#');
        if (strlen($hex) !== 6 || !ctype_xdigit($hex)) return 0.0;
        $rgb = array_map(function ($part) {
            $v = hexdec($part) / 255;
            return $v <= 0.03928 ? $v / 12.92 : pow(($v + 0.055) / 1.055, 2.4);
        }, str_split($hex, 2));
        return 0.2126 * $rgb[0] + 0.7152 * $rgb[1] + 0.0722 * $rgb[2];
    };
    $contrastOf = function ($bg, $text) use ($luminance) {
        $a = $luminance($bg);
        $b = $luminance($text);
        if ($a < $b) { [$a, $b] = [$b, $a]; }
        return ($a + 0.05) / ($b + 0.05);
    };
@endphp
<div class="box box-primary">
    <div class="box-header with-border">
        <h3 class="box-title">{{ __('Daftar pengumuman') }}</h3>
        <div class="box-tools">
            <div class="btn-group" style="margin-right: 8px;">
                <a href="{{ route('admin.announcements', ['filter' => 'all']) }}" class="btn btn-xs {{ ($filter ?? 'all') === 'all' ? 'btn-primary' : 'btn-default' }}">{{ __('Semua') }}</a>
                <a href="{{ route('admin.announcements', ['filter' => 'live']) }}" class="btn btn-xs {{ ($filter ?? 'all') === 'live' ? 'btn-primary' : 'btn-default' }}">{{ __('Live') }}</a>
                <a href="{{ route('admin.announcements', ['filter' => 'scheduled']) }}" class="btn btn-xs {{ ($filter ?? 'all') === 'scheduled' ? 'btn-primary' : 'btn-default' }}">{{ __('Terjadwal') }}</a>
                <a href="{{ route('admin.announcements', ['filter' => 'off']) }}" class="btn btn-xs {{ ($filter ?? 'all') === 'off' ? 'btn-primary' : 'btn-default' }}">{{ __('Mati') }}</a>
            </div>
            <button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#newAnnouncementModal">{{ __('Tambah pengumuman') }}</button>
        </div>
    </div>
    <div class="box-body table-responsive no-padding">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>{{ __('Judul') }}</th>
                    <th>{{ __('Tema') }}</th>
                    <th>{{ __('Font') }}</th>
                    <th>{{ __('Jadwal') }}</th>
                    <th class="text-center">{{ __('Aktif') }}</th>
                    <th class="text-center">{{ __('Urutan') }}</th>
                    <th class="text-center"><span class="sr-only">{{ __('Aksi') }}</span></th>
                </tr>
            </thead>
            <tbody>
                @forelse ($announcements as $item)
                    <tr>
                        <td>
                            <strong>{{ $item->title }}</strong>
                            <br><small class="text-muted">{{ \Illuminate\Support\Str::limit($item->message, 80) }}</small>
                        </td>
                        <td>
                            <span class="label" style="background: {{ $item->accent_color }}; color: #fff;">{{ $item->tone }}</span>
                            <br><small><code>{{ $item->accent_color }}</code> / <code>{{ $item->background_color }}</code> / <code>{{ $item->text_color }}</code></small>
                        </td>
                        <td><code>{{ $item->font }}</code></td>
                        <td>
                            <small>
                                {{ $item->starts_at ? $item->starts_at->format('d M Y H:i') : __('Langsung') }}
                                &ndash;
                                {{ $item->ends_at ? $item->ends_at->format('d M Y H:i') : __('Tanpa batas') }}
                            </small>
                        </td>
                        <td class="text-center">
                            @if ($item->isLive())
                                <span class="label label-success">{{ __('Live') }}</span>
                            @elseif ($item->is_active)
                                <span class="label label-warning">{{ __('Terjadwal') }}</span>
                            @else
                                <span class="label label-default">{{ __('Mati') }}</span>
                            @endif
                        </td>
                        <td class="text-center">{{ $item->sort }}</td>
                        <td class="text-center">
                            <button type="button" class="btn btn-xs btn-default" data-toggle="modal" data-target="#editAnnouncementModal{{ $item->id }}">{{ __('Ubah') }}</button>
                            <form action="{{ route('admin.announcements.duplicate', $item->id) }}" method="POST" style="display: inline;">
                                {!! csrf_field() !!}
                                <button type="submit" class="btn btn-xs btn-default" title="{{ __('Duplikat sebagai draf baru') }}">{{ __('Duplikat') }}</button>
                            </form>
                        </td>
                    </tr>
                @empty
                    <tr>
                        <td colspan="7" class="ptero-empty">{{ __('Belum ada pengumuman. Tambahkan satu agar tampil di dashboard dan konsol client.') }}</td>
                    </tr>
                @endforelse
            </tbody>
        </table>
    </div>
    <div class="box-footer">
        <p class="help-block" style="margin: 0;">{{ __('Banner client hanya menampilkan satu yang live dengan urutan terkecil. Live preview di bawah mengikuti warna dan font yang dipilih.') }}</p>
    </div>
</div>

@if ($announcements->where('is_active', true)->count())
<div class="box">
    <div class="box-header with-border">
        <h3 class="box-title">{{ __('Live preview') }}</h3>
    </div>
    <div class="box-body">
        @foreach ($announcements->where('is_active', true)->take(3) as $preview)
            @php $contrast = $contrastOf($preview->background_color, $preview->text_color); @endphp
            <div style="display: flex; gap: 12px; align-items: flex-start; padding: 12px 16px; margin-bottom: 12px; border-radius: 2px; border: 1px solid #e5e7eb; border-left: 4px solid {{ $preview->accent_color }}; background: {{ $preview->background_color }}; color: {{ $preview->text_color }}; font-family: {{ $preview->font === 'mono' ? "'JetBrains Mono', ui-monospace, monospace" : ($preview->font === 'display' ? "'Inter Tight', 'Inter', sans-serif" : "'Inter', system-ui, sans-serif") }};">
                <div style="flex: 1; min-width: 0;">
                    <div style="font-size: 10px; text-transform: uppercase; letter-spacing: 0.08em; opacity: 0.7;">{{ $preview->title }} &middot; {{ $preview->tone }} &middot; {{ number_format($contrast, 2) }}:1</div>
                    <div style="font-size: 14px; line-height: 1.5; margin-top: 2px; {{ $preview->font === 'display' ? 'font-weight: 600;' : '' }}">{{ $preview->message }}</div>
                    @if ($preview->message_id)
                        <div style="font-size: 12px; margin-top: 4px; opacity: 0.85;">ID: {{ $preview->message_id }}</div>
                    @endif
                    @if ($contrast < 4.5)
                        <div style="font-size: 12px; margin-top: 6px; font-weight: 600;">{{ __('Kontras rendah, teks sulit dibaca. Gelapkan latar atau cerahkan teks.') }}</div>
                    @endif
                </div>
            </div>
            <div style="display: flex; gap: 12px; margin-bottom: 16px;">
                <div style="flex: 1; padding: 10px 12px; border-radius: 2px; border: 1px solid #e5e7eb; background: #ffffff; color: {{ $preview->text_color }}; border-left: 4px solid {{ $preview->accent_color }}; font-size: 13px;">{{ __('Mode terang:') }} {{ \Illuminate\Support\Str::limit($preview->message, 60) }}</div>
                <div style="flex: 1; padding: 10px 12px; border-radius: 2px; border: 1px solid #1f2937; background: #111827; color: {{ $preview->text_color }}; border-left: 4px solid {{ $preview->accent_color }}; font-size: 13px;">{{ __('Mode gelap:') }} {{ \Illuminate\Support\Str::limit($preview->message, 60) }}</div>
            </div>
        @endforeach
        <p class="help-block" style="margin: 0;">{{ __('Rasio 4.50:1 adalah batas aman teks normal. Pratinjau terang dan gelap memakai teks pilihanmu di atas halaman terang dan gelap.') }}</p>
    </div>
</div>
@endif

<div class="modal fade" id="newAnnouncementModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <form action="{{ route('admin.announcements') }}" method="POST">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="{{ __('Tutup') }}"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title">{{ __('Tambah pengumuman') }}</h4>
                </div>
                <div class="modal-body">
                    <div class="ptero-form-grid">
                        <div class="form-group">
                            <label for="newAnnouncementTitle" class="control-label field-required">{{ __('Judul') }}</label>
                            <input type="text" name="title" id="newAnnouncementTitle" class="form-control" maxlength="80" placeholder="{{ __('Maintenance node') }}" autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementSort" class="control-label">{{ __('Urutan') }}</label>
                            <input type="number" name="sort" id="newAnnouncementSort" class="form-control" value="0" min="0" max="9999" inputmode="numeric">
                            <p class="help-block">{{ __('Angka kecil tampil lebih dulu bila beberapa live bersamaan.') }}</p>
                        </div>
                        <div class="form-group span-2">
                            <label for="newAnnouncementMessage" class="control-label field-required">{{ __('Isi pesan') }}</label>
                            <textarea name="message" id="newAnnouncementMessage" class="form-control" rows="2" maxlength="500" placeholder="{{ __('Maintenance node jam 02:00, server restart otomatis.') }}"></textarea>
                            <p class="help-block">{{ __('Teks utama untuk akun Inggris. Isi versi Indonesia di bawah bila berbeda.') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementTitleId" class="control-label">{{ __('Judul Indonesia') }}</label>
                            <input type="text" name="title_id" id="newAnnouncementTitleId" class="form-control" maxlength="80" placeholder="{{ __('Perawatan node') }}" autocomplete="off">
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementMessageId" class="control-label">{{ __('Isi Indonesia') }}</label>
                            <textarea name="message_id" id="newAnnouncementMessageId" class="form-control" rows="2" maxlength="500" placeholder="{{ __('Perawatan node jam 02:00, server restart otomatis.') }}"></textarea>
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementTone" class="control-label field-required">{{ __('Nada') }}</label>
                            <select name="tone" id="newAnnouncementTone" class="form-control">
                                @foreach ($tones as $tone)
                                    <option value="{{ $tone }}">{{ ucfirst($tone) }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementFont" class="control-label field-required">{{ __('Font banner') }}</label>
                            <select name="font" id="newAnnouncementFont" class="form-control">
                                @foreach ($fonts as $font)
                                    <option value="{{ $font }}">{{ ucfirst($font) }}</option>
                                @endforeach
                            </select>
                            <p class="help-block">{{ __('Sans untuk teks biasa, mono untuk data, display untuk judul tegas.') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementAccent" class="control-label field-required">{{ __('Warna aksen') }}</label>
                            <input type="color" name="accent_color" id="newAnnouncementAccent" class="form-control" value="#2563eb" style="height: 40px; padding: 4px;">
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementBg" class="control-label field-required">{{ __('Warna latar') }}</label>
                            <input type="color" name="background_color" id="newAnnouncementBg" class="form-control" value="#0f172a" style="height: 40px; padding: 4px;">
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementText" class="control-label field-required">{{ __('Warna teks') }}</label>
                            <input type="color" name="text_color" id="newAnnouncementText" class="form-control" value="#f8fafc" style="height: 40px; padding: 4px;">
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementStarts" class="control-label">{{ __('Mulai') }}</label>
                            <input type="datetime-local" name="starts_at" id="newAnnouncementStarts" class="form-control">
                            <p class="help-block">{{ __('Kosongkan untuk tampil langsung.') }}</p>
                        </div>
                        <div class="form-group">
                            <label for="newAnnouncementEnds" class="control-label">{{ __('Selesai') }}</label>
                            <input type="datetime-local" name="ends_at" id="newAnnouncementEnds" class="form-control">
                            <p class="help-block">{{ __('Kosongkan bila tanpa batas.') }}</p>
                        </div>
                        <div class="form-group span-2">
                            <div class="ptero-check">
                                <input type="checkbox" name="is_active" id="newAnnouncementActive" value="1" checked>
                                <label for="newAnnouncementActive">{{ __('Aktifkan pengumuman ini') }}</label>
                            </div>
                        </div>
                    </div>
                    <div id="newAnnouncementPreview" style="display: flex; gap: 12px; padding: 12px 16px; margin-top: 12px; border-radius: 2px; border: 1px solid #e5e7eb;"></div>
                </div>
                <div class="modal-footer">
                    {!! csrf_field() !!}
                    <button type="button" class="btn btn-default" data-dismiss="modal">{{ __('Batal') }}</button>
                    <button type="submit" class="btn btn-primary">{{ __('Tambah pengumuman') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>

@foreach ($announcements as $item)
    <div class="modal fade" id="editAnnouncementModal{{ $item->id }}" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <form action="{{ route('admin.announcements.update', $item->id) }}" method="POST">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="{{ __('Tutup') }}"><span aria-hidden="true">&times;</span></button>
                        <h4 class="modal-title">{{ __('Ubah pengumuman') }}</h4>
                    </div>
                    <div class="modal-body">
                        <div class="ptero-form-grid">
                            <div class="form-group">
                                <label for="editAnnouncementTitle{{ $item->id }}" class="control-label field-required">{{ __('Judul') }}</label>
                                <input type="text" name="title" id="editAnnouncementTitle{{ $item->id }}" class="form-control" maxlength="80" value="{{ $item->title }}">
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementSort{{ $item->id }}" class="control-label">{{ __('Urutan') }}</label>
                                <input type="number" name="sort" id="editAnnouncementSort{{ $item->id }}" class="form-control" value="{{ $item->sort }}" min="0" max="9999" inputmode="numeric">
                            </div>
                            <div class="form-group span-2">
                                <label for="editAnnouncementMessage{{ $item->id }}" class="control-label field-required">{{ __('Isi pesan') }}</label>
                                <textarea name="message" id="editAnnouncementMessage{{ $item->id }}" class="form-control" rows="2" maxlength="500">{{ $item->message }}</textarea>
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementTitleId{{ $item->id }}" class="control-label">{{ __('Judul Indonesia') }}</label>
                                <input type="text" name="title_id" id="editAnnouncementTitleId{{ $item->id }}" class="form-control" maxlength="80" value="{{ $item->title_id }}">
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementMessageId{{ $item->id }}" class="control-label">{{ __('Isi Indonesia') }}</label>
                                <textarea name="message_id" id="editAnnouncementMessageId{{ $item->id }}" class="form-control" rows="2" maxlength="500">{{ $item->message_id }}</textarea>
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementTone{{ $item->id }}" class="control-label field-required">{{ __('Nada') }}</label>
                                <select name="tone" id="editAnnouncementTone{{ $item->id }}" class="form-control">
                                    @foreach ($tones as $tone)
                                        <option value="{{ $tone }}" @if ($item->tone === $tone) selected @endif>{{ ucfirst($tone) }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementFont{{ $item->id }}" class="control-label field-required">{{ __('Font banner') }}</label>
                                <select name="font" id="editAnnouncementFont{{ $item->id }}" class="form-control">
                                    @foreach ($fonts as $font)
                                        <option value="{{ $font }}" @if ($item->font === $font) selected @endif>{{ ucfirst($font) }}</option>
                                    @endforeach
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementAccent{{ $item->id }}" class="control-label field-required">{{ __('Warna aksen') }}</label>
                                <input type="color" name="accent_color" id="editAnnouncementAccent{{ $item->id }}" class="form-control" value="{{ $item->accent_color }}" style="height: 40px; padding: 4px;">
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementBg{{ $item->id }}" class="control-label field-required">{{ __('Warna latar') }}</label>
                                <input type="color" name="background_color" id="editAnnouncementBg{{ $item->id }}" class="form-control" value="{{ $item->background_color }}" style="height: 40px; padding: 4px;">
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementText{{ $item->id }}" class="control-label field-required">{{ __('Warna teks') }}</label>
                                <input type="color" name="text_color" id="editAnnouncementText{{ $item->id }}" class="form-control" value="{{ $item->text_color }}" style="height: 40px; padding: 4px;">
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementStarts{{ $item->id }}" class="control-label">{{ __('Mulai') }}</label>
                                <input type="datetime-local" name="starts_at" id="editAnnouncementStarts{{ $item->id }}" class="form-control" value="{{ $item->starts_at ? $item->starts_at->format('Y-m-d\TH:i') : '' }}">
                            </div>
                            <div class="form-group">
                                <label for="editAnnouncementEnds{{ $item->id }}" class="control-label">{{ __('Selesai') }}</label>
                                <input type="datetime-local" name="ends_at" id="editAnnouncementEnds{{ $item->id }}" class="form-control" value="{{ $item->ends_at ? $item->ends_at->format('Y-m-d\TH:i') : '' }}">
                            </div>
                            <div class="form-group span-2">
                                <div class="ptero-check">
                                    <input type="checkbox" name="is_active" id="editAnnouncementActive{{ $item->id }}" value="1" @if ($item->is_active) checked @endif>
                                    <label for="editAnnouncementActive{{ $item->id }}">{{ __('Aktifkan pengumuman ini') }}</label>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        {!! csrf_field() !!}
                        <input type="hidden" name="_method_action" value="">
                        <button type="button" class="btn btn-danger pull-left js-delete-announcement" data-title="{{ $item->title }}">{{ __('Hapus') }}</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">{{ __('Batal') }}</button>
                        <button type="submit" class="btn btn-primary">{{ __('Simpan') }}</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endforeach
@endsection

@section('footer-scripts')
    @parent
    <script>
        // Live preview in the create modal: the same three values the client
        // banner reads, so what the admin sees is what the client gets. No
        // submit happens here, this only repaints the preview box.
        (function () {
            var title = document.getElementById('newAnnouncementTitle');
            var message = document.getElementById('newAnnouncementMessage');
            var accent = document.getElementById('newAnnouncementAccent');
            var bg = document.getElementById('newAnnouncementBg');
            var text = document.getElementById('newAnnouncementText');
            var preview = document.getElementById('newAnnouncementPreview');
            if (!preview) return;
            function fontFor(value) {
                if (value === 'mono') return "'JetBrains Mono', ui-monospace, monospace";
                if (value === 'display') return "'Inter Tight', 'Inter', sans-serif";
                return "'Inter', system-ui, sans-serif";
            }
            function repaint() {
                var fontSel = document.getElementById('newAnnouncementFont');
                preview.style.borderLeft = '4px solid ' + accent.value;
                preview.style.background = bg.value;
                preview.style.color = text.value;
                preview.style.fontFamily = fontFor(fontSel ? fontSel.value : 'sans');
                preview.innerHTML = '';
                var copy = document.createElement('div');
                copy.style.flex = '1';
                var label = document.createElement('div');
                label.style.fontSize = '10px';
                label.style.opacity = '0.7';
                label.textContent = (title.value || 'Judul') + ' - live preview';
                var body = document.createElement('div');
                body.style.fontSize = '14px';
                body.textContent = message.value || 'Isi pesan tampil di sini.';
                copy.appendChild(label);
                copy.appendChild(body);
                preview.appendChild(copy);
            }
            [title, message, accent, bg, text, document.getElementById('newAnnouncementFont')].forEach(function (el) {
                if (el) el.addEventListener('input', repaint);
            });
            repaint();
        })();
        $('.js-delete-announcement').on('click', function () {
            var button = $(this);
            var form = button.closest('form');

            swal({
                title: 'Hapus pengumuman ini?',
                text: button.data('title') + @json(__(' akan hilang dari dashboard dan konsol client.')),
                type: 'warning',
                showCancelButton: true,
                confirmButtonText: 'Hapus',
                cancelButtonText: 'Batal',
                closeOnConfirm: false
            }, function (confirmed) {
                if (!confirmed) return;
                form.find('input[name="_method_action"]').val('delete');
                form[0].submit();
            });
        });
    </script>
@endsection
