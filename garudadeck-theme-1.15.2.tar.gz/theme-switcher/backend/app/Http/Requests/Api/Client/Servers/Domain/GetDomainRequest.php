<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers\Domain;

use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;

class GetDomainRequest extends ClientApiRequest
{
    public function permission(): string
    {
        return Permission::ACTION_DOMAIN_READ;
    }
}
