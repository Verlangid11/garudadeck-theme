<?php

namespace Pterodactyl\Http\Requests\Api\Client\Servers\Domain;

use Pterodactyl\Models\Permission;
use Pterodactyl\Http\Requests\Api\Client\ClientApiRequest;

class UpdateDomainRequest extends ClientApiRequest
{
    public function permission(): string
    {
        return Permission::ACTION_DOMAIN_UPDATE;
    }

    public function rules(): array
    {
        return [
            'domain' => 'required|string|max:253',
        ];
    }
}
