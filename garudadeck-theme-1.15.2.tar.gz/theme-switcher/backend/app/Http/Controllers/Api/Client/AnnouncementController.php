<?php

namespace Pterodactyl\Http\Controllers\Api\Client;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Cache;
use Pterodactyl\Models\Announcement;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;

/**
 * Read the live global announcement banner.
 *
 * Many rows can exist, but the client only shows one: the live row with the
 * smallest sort wins, so the admin orders by urgency without touching code.
 * A row is live when it is active and now sits inside its optional schedule
 * window. Colors and font ship in the payload so the banner follows the theme
 * picked in the admin page instead of a hardcoded style.
 */
class AnnouncementController extends ClientApiController
{
    public const CACHE_KEY = 'announcement:live-row';
    public const CACHE_TTL_SECONDS = 60;

    public function index(Request $request): array
    {
        // Cache one entry per language: the row is shared, but the text is
        // picked per account language, so en and id need separate entries.
        $locale = strtolower(substr(trim((string) ($request->user()?->language ?? config('app.locale', 'en'))), 0, 2));
        $locale = $locale === 'id' ? 'id' : 'en';
        $key = self::CACHE_KEY . ':' . $locale;

        // One row is shared by every dashboard and console on the panel, so a
        // short cache keeps a flood of clients from hitting the table on each
        // paint. Sixty seconds is the middle ground: short enough that an
        // admin edit appears quickly, long enough to absorb page reloads.
        $cached = Cache::remember($key, self::CACHE_TTL_SECONDS, function () use ($locale) {
            $live = Announcement::orderBy('sort')->orderBy('id')->get()->first(fn (Announcement $row) => $row->isLive());

            if (is_null($live)) {
                return null;
            }

            $text = $live->localized($locale);

            return [
                'message' => $text['message'],
                'title' => $text['title'],
                'tone' => $live->tone,
                'font' => $live->font,
                'accent_color' => $live->accent_color,
                'background_color' => $live->background_color,
                'text_color' => $live->text_color,
            ];
        });

        if (!is_null($cached)) {
            return [
                'object' => 'announcement',
                'attributes' => array_merge($cached, ['enabled' => true]),
            ];
        }

        // Fall back to the legacy single-row setting so an upgrade keeps
        // showing the old banner until the admin moves it to the new page.
        $enabled = filter_var(config('app.announcement_enabled'), FILTER_VALIDATE_BOOLEAN);
        $message = trim((string) config('app.announcement'));

        if (!$enabled || $message === '') {
            return [
                'object' => 'announcement',
                'attributes' => [
                    'message' => null,
                    'title' => null,
                    'tone' => 'info',
                    'font' => 'sans',
                    'accent_color' => '#2563eb',
                    'background_color' => null,
                    'text_color' => null,
                    'enabled' => false,
                ],
            ];
        }

        return [
            'object' => 'announcement',
            'attributes' => [
                'message' => $message,
                'title' => null,
                'tone' => 'info',
                'font' => 'sans',
                'accent_color' => '#2563eb',
                'background_color' => null,
                'text_color' => null,
                'enabled' => true,
            ],
        ];
    }
}
