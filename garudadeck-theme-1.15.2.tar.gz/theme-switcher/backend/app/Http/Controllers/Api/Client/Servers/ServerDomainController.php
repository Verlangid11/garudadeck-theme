<?php

namespace Pterodactyl\Http\Controllers\Api\Client\Servers;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\ServerCustomDomain;
use Pterodactyl\Http\Controllers\Api\Client\ClientApiController;
use Pterodactyl\Services\Servers\ServerDomainVerificationService;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domain\GetDomainRequest;
use Pterodactyl\Http\Requests\Api\Client\Servers\Domain\UpdateDomainRequest;
use Symfony\Component\HttpKernel\Exception\BadRequestHttpException;

/**
 * Read and write the single custom join domain linked to a server.
 *
 * The GET returns the row plus the two DNS instructions the owner must add
 * at their provider, so the page can show both without a second call. The
 * POST replaces the row (never edits it in place) so a replaced hostname
 * starts again at pending with a fresh token, instead of inheriting a green
 * badge it never earned.
 */
class ServerDomainController extends ClientApiController
{
    public function __construct(private ServerDomainVerificationService $verifier)
    {
        parent::__construct();
    }

    public function index(GetDomainRequest $request, Server $server): array
    {
        $this->useAccountLocale($request);
        $domain = $server->customDomain()->first();

        if (is_null($domain)) {
            return [
                'object' => 'server_custom_domain',
                'attributes' => [
                    'domain' => null,
                    'status' => null,
                    'join_address' => null,
                    'last_error' => null,
                    'verified_at' => null,
                    'last_checked_at' => null,
                    'instructions' => [],
                    'token' => null,
                ],
            ];
        }

        return $this->render($server, $domain);
    }

    public function store(UpdateDomainRequest $request, Server $server): array
    {
        $this->useAccountLocale($request);
        $host = ServerCustomDomain::normalize((string) $request->input('domain'));

        if (is_null($host) || !ServerCustomDomain::isUsableHostname($host)) {
            throw new BadRequestHttpException('Enter a plain hostname, for example play.example.com.');
        }

        if (ServerCustomDomain::query()->where('domain', $host)->where('server_id', '!=', $server->id)->exists()) {
            throw new BadRequestHttpException('That hostname is already linked to another server.');
        }

        $previous = $server->customDomain()->first()?->domain;

        // A replaced hostname restarts at pending with a fresh token: keeping
        // the old token would let a stale TXT record pass for a new name.
        $domain = $server->customDomain()->updateOrCreate(
            ['server_id' => $server->id],
            [
                'domain' => $host,
                'token' => ServerDomainVerificationService::issueToken(),
                'status' => ServerCustomDomain::STATUS_PENDING,
                'last_error' => null,
                'verified_at' => null,
                'last_checked_at' => null,
            ]
        );

        Activity::event('server:domain.update')
            ->property(['old' => $previous, 'new' => $domain->domain])
            ->log();

        return $this->render($server, $domain->refresh());
    }

    public function verify(GetDomainRequest $request, Server $server): array
    {
        $this->useAccountLocale($request);
        $domain = $server->customDomain()->first();

        if (is_null($domain)) {
            throw new BadRequestHttpException('Link a hostname first, then verify it.');
        }

        $targetIp = ServerDomainVerificationService::resolveTargetIp($server);

        if (is_null($targetIp)) {
            throw new BadRequestHttpException('This server has no public address to check yet.');
        }

        $result = $this->verifier->verify($domain, $targetIp);
        $status = $result['ok'] ? 'verified' : 'failed';

        Activity::event('server:domain.verify')
            ->property(['domain' => $domain->domain, 'status' => $status])
            ->log();

        return array_merge($this->render($server, $domain->refresh()), [
            'verified' => $result['ok'],
        ]);
    }

    public function destroy(UpdateDomainRequest $request, Server $server): JsonResponse
    {
        $domain = $server->customDomain()->first();

        if (!is_null($domain)) {
            Activity::event('server:domain.delete')->property('domain', $domain->domain)->log();
            $domain->delete();
        }

        return new JsonResponse([], Response::HTTP_NO_CONTENT);
    }

    private function useAccountLocale(Request $request): void
    {
        // The client API stack never runs LanguageMiddleware, so __() would
        // stay in English even for an Indonesian account. The web session
        // carries the same user, and that is where the language lives.
        $language = $request->user()?->language ?? config('app.locale', 'en');
        app()->setLocale((string) $language);
    }

    private function render(Server $server, ServerCustomDomain $domain): array
    {
        $primary = $server->allocation()->first();
        $targetIp = ServerDomainVerificationService::resolveTargetIp($server);
        $join = $primary && $targetIp && $domain->status === ServerCustomDomain::STATUS_VERIFIED
            ? sprintf('%s:%d', $domain->domain, $primary->port)
            : null;

        $instructions = $targetIp ? ServerDomainVerificationService::freshInstructions($domain, $targetIp) : null;

        return [
            'object' => 'server_custom_domain',
            'attributes' => [
                'domain' => $domain->domain,
                'status' => $domain->status,
                'join_address' => $join,
                'last_error' => $domain->last_error,
                'verified_at' => $domain->verified_at?->toAtomString(),
                'last_checked_at' => $domain->last_checked_at?->toAtomString(),
                'instructions' => $instructions['instructions'] ?? [],
                'token' => $domain->token,
            ],
        ];
    }
}
