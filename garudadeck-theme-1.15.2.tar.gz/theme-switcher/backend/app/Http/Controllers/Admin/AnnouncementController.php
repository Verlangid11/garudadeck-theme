<?php

namespace Pterodactyl\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Cache;
use Prologue\Alerts\AlertsMessageBag;
use Pterodactyl\Models\Announcement;
use Pterodactyl\Http\Controllers\Controller;

class AnnouncementController extends Controller
{
    public function __construct(protected AlertsMessageBag $alert)
    {
    }

    private function forgetLiveCache(): void
    {
        Cache::forget('announcement:live-row:en');
        Cache::forget('announcement:live-row:id');
        Cache::forget('announcement:live-row');
    }

    /**
     * Render the announcement list with a live preview of the client banner.
     */
    public function index(): View
    {
        $filter = request()->query('filter', 'all');

        $announcements = Announcement::orderBy('sort')->orderBy('id')->get();

        if ($filter === 'live') {
            $announcements = $announcements->filter(fn (Announcement $row) => $row->isLive())->values();
        } elseif ($filter === 'scheduled') {
            $announcements = $announcements->filter(fn (Announcement $row) => $row->is_active && !$row->isLive())->values();
        } elseif ($filter === 'off') {
            $announcements = $announcements->filter(fn (Announcement $row) => !$row->is_active)->values();
        }

        return view('admin.announcements.index', [
            'announcements' => $announcements,
            'filter' => in_array($filter, ['all', 'live', 'scheduled', 'off']) ? $filter : 'all',
            'tones' => Announcement::TONES,
            'fonts' => Announcement::FONTS,
        ]);
    }

    /**
     * Store a newly created announcement.
     */
    public function store(Request $request): RedirectResponse
    {
        $data = $request->validate(Announcement::$validationRules);
        $data['sort'] = $data['sort'] ?? 0;
        $data['is_active'] = $request->boolean('is_active');

        Announcement::create($data);
        $this->forgetLiveCache();

        $this->alert->success(trans('admin/notices.announcement_created'))->flash();

        return redirect()->route('admin.announcements');
    }

    /**
     * Update an existing announcement, or delete it if requested.
     */
    public function update(Request $request, Announcement $announcement): RedirectResponse
    {
        if ($request->input('_method_action') === 'delete') {
            $announcement->delete();
            $this->forgetLiveCache();

            $this->alert->success(trans('admin/notices.announcement_deleted'))->flash();

            return redirect()->route('admin.announcements');
        }

        $data = $request->validate(Announcement::$validationRules);
        $data['sort'] = $data['sort'] ?? 0;
        $data['is_active'] = $request->boolean('is_active');

        $announcement->update($data);
        $this->forgetLiveCache();

        $this->alert->success(trans('admin/notices.announcement_updated'))->flash();

        return redirect()->route('admin.announcements');
    }

    /**
     * Duplicate a row for a recurring notice: same copy and theme, schedule
     * cleared so the copy starts as a draft the admin can date.
     */
    public function duplicate(Announcement $announcement): RedirectResponse
    {
        $copy = $announcement->replicate([
            'starts_at',
            'ends_at',
        ]);
        $copy->is_active = false;
        $copy->sort = $announcement->sort + 1;
        $copy->save();
        $this->forgetLiveCache();

        $this->alert->success(trans('admin/notices.announcement_duplicated'))->flash();

        return redirect()->route('admin.announcements');
    }
}
