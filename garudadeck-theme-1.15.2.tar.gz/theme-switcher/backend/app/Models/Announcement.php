<?php

namespace Pterodactyl\Models;

/**
 * A global client banner row managed from its own admin page.
 *
 * @property int $id
 * @property string $title
 * @property string|null $title_id
 * @property string $message
 * @property string|null $message_id
 * @property string $tone
 * @property string $font
 * @property string $accent_color
 * @property string $background_color
 * @property string $text_color
 * @property int $sort
 * @property bool $is_active
 * @property \Illuminate\Support\Carbon|null $starts_at
 * @property \Illuminate\Support\Carbon|null $ends_at
 * @property \Illuminate\Support\Carbon $created_at
 * @property \Illuminate\Support\Carbon $updated_at
 */
class Announcement extends Model
{
    public const TONES = ['info', 'success', 'warning', 'danger'];
    public const FONTS = ['sans', 'mono', 'display'];

    protected $table = 'announcements';

    protected $fillable = [
        'title',
        'title_id',
        'message',
        'message_id',
        'tone',
        'font',
        'accent_color',
        'background_color',
        'text_color',
        'sort',
        'is_active',
        'starts_at',
        'ends_at',
    ];

    protected $casts = [
        'sort' => 'integer',
        'is_active' => 'boolean',
        'starts_at' => 'datetime',
        'ends_at' => 'datetime',
    ];

    public static array $validationRules = [
        'title' => 'required|string|max:80',
        'title_id' => 'nullable|string|max:80',
        'message' => 'required|string|max:500',
        'message_id' => 'nullable|string|max:500',
        'tone' => 'required|string|in:info,success,warning,danger',
        'font' => 'required|string|in:sans,mono,display',
        'accent_color' => 'required|string|regex:/^#[0-9a-fA-F]{6}$/',
        'background_color' => 'required|string|regex:/^#[0-9a-fA-F]{6}$/',
        'text_color' => 'required|string|regex:/^#[0-9a-fA-F]{6}$/',
        'sort' => 'nullable|integer|min:0|max:9999',
        'starts_at' => 'nullable|date',
        'ends_at' => 'nullable|date|after_or_equal:starts_at',
        'is_active' => 'boolean',
    ];

    public function getRouteKeyName(): string
    {
        return 'id';
    }

    /**
     * Text for one locale: Indonesian accounts read title_id and message_id
     * when the admin filled them, everyone else reads the default copy. A
     * blank translation falls back to the default so a half-filled row never
     * renders an empty banner.
     */
    public function localized(string $locale): array
    {
        $useId = strtolower(substr(trim($locale), 0, 2)) === 'id';
        $titleId = trim((string) $this->title_id);
        $messageId = trim((string) $this->message_id);

        return [
            'title' => $useId && $titleId !== '' ? $titleId : $this->title,
            'message' => $useId && $messageId !== '' ? $messageId : $this->message,
        ];
    }

    public function isLive(): bool
    {
        if (!$this->is_active) {
            return false;
        }

        $now = now();

        if ($this->starts_at && $now->lt($this->starts_at)) {
            return false;
        }

        if ($this->ends_at && $now->gt($this->ends_at)) {
            return false;
        }

        return true;
    }
}
