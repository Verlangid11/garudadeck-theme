<?php

namespace Pterodactyl\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * One custom join domain linked to a server.
 *
 * The row never claims to own DNS: it records the hostname the owner asked
 * for, the token they must publish in a TXT record, and the last real DNS
 * answer the panel measured. Before any check the hostname is normalized the
 * same way the checks compare it, so "Play.Example.com." with a stray dot or
 * a pasted scheme cannot slip past as something else.
 */
class ServerCustomDomain extends Model
{
    public const STATUS_PENDING = 'pending';
    public const STATUS_VERIFIED = 'verified';
    public const STATUS_FAILED = 'failed';

    protected $table = 'server_custom_domains';

    protected $guarded = ['id', 'created_at', 'updated_at'];

    protected $casts = [
        'server_id' => 'integer',
        'verified_at' => 'datetime',
        'last_checked_at' => 'datetime',
    ];

    /**
     * Strip what a pasted URL adds (scheme, path, trailing dot, case) so the
     * stored hostname is exactly what DNS looks up. Returns null when nothing
     * usable remains, so the caller can ask for a real domain instead of
     * storing an empty row.
     */
    public static function normalize(?string $value): ?string
    {
        $value = strtolower(trim((string) $value));
        if ($value === '') {
            return null;
        }

        $host = parse_url($value, PHP_URL_HOST);
        $host = is_string($host) ? $host : $value;
        $host = preg_replace('#^https?://#i', '', (string) $host);
        $host = explode('/', (string) $host, 2)[0];
        $host = rtrim(trim((string) $host), '.' . " \t\n\r\0\x0B");

        return $host !== '' ? $host : null;
    }

    public static function isUsableHostname(string $host): bool
    {
        if (strlen($host) > 253) {
            return false;
        }

        return (bool) preg_match('/^(?!-)[a-z0-9-]{1,63}(?<!-)(\.(?!-)[a-z0-9-]{1,63}(?<!-))+$/', $host);
    }

    public static array $validationRules = [
        'domain' => 'required|string|max:253',
    ];

    public function server(): BelongsTo
    {
        return $this->belongsTo(Server::class);
    }

    public function getRouteKeyName(): string
    {
        return 'id';
    }
}
