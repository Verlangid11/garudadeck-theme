<?php

namespace Pterodactyl\Services\Servers;

use Illuminate\Support\Str;
use Pterodactyl\Models\Server;
use Pterodactyl\Models\ServerCustomDomain;

/**
 * Links one hostname to one server and checks it with real DNS lookups.
 *
 * Each step names the record and the value it compares, because a green
 * "verified" badge without that is a claim, not a measurement. The check
 * reads two records: the A record must resolve to the server's join IP, and
 * the ownership TXT record must carry the exact token the panel issued.
 * Either side failing marks the row failed with the reason on the row, never
 * with a bare status the user has to guess about.
 */
class ServerDomainVerificationService
{
    public const TXT_PREFIX = '_ptero-verify';

    public static function resolveTargetIp(Server $server): ?string
    {
        $allocation = $server->allocation()->first();

        if (is_null($allocation)) {
            return null;
        }

        $candidates = array_filter([
            $allocation->ip ?? null,
            $allocation->ip_alias ?? null,
        ]);

        foreach ($candidates as $candidate) {
            $candidate = trim((string) $candidate);
            if ($candidate === '' || self::isWildcard($candidate)) {
                continue;
            }
            // A hostname alias is fine for display, but the DNS check needs a
            // literal address: only accept values that already look like IPs.
            // Otherwise a label like bio.verlang.id would be compared against
            // gethostbyname output and never match.
            if (filter_var($candidate, FILTER_VALIDATE_IP)) {
                return $candidate;
            }
        }

        $node = $server->relationLoaded('node') ? $server->node : $server->node()->first();

        if (!is_null($node)) {
            $fromFqdn = @gethostbyname((string) $node->fqdn);
            if (is_string($fromFqdn) && $fromFqdn !== '' && !self::isWildcard($fromFqdn) && $fromFqdn !== (string) $node->fqdn) {
                return $fromFqdn;
            }
        }

        return null;
    }

    public static function isWildcard(string $ip): bool
    {
        return $ip === '0.0.0.0' || $ip === '::' || $ip === '0:0:0:0:0:0:0:0';
    }

    /**
     * @return array{token: string, instructions: array<int, array{type: string, host: string, value: string, note: string}>}
     */
    public static function freshInstructions(ServerCustomDomain $domain, string $targetIp): array
    {
        $host = $domain->domain;

        return [
            'token' => $domain->token,
            'instructions' => [
                [
                    'type' => 'A',
                    'host' => $host,
                    'value' => $targetIp,
                    'note' => (string) __('theme.server.domain.note_a'),
                ],
                [
                    'type' => 'TXT',
                    'host' => self::TXT_PREFIX . '.' . $host,
                    'value' => $domain->token,
                    'note' => (string) __('theme.server.domain.note_txt'),
                ],
            ],
        ];
    }

    public static function issueToken(): string
    {
        return 'ptero-' . Str::random(40);
    }

    /**
     * @return array{ok: bool, error: string|null}
     */
    public function verify(ServerCustomDomain $domain, string $targetIp): array
    {
        $failure = $this->checkOwnership($domain);
        if ($failure !== null) {
            $this->mark($domain, ServerCustomDomain::STATUS_FAILED, $failure);

            return ['ok' => false, 'error' => $failure];
        }

        $failure = $this->checkTarget($domain->domain, $targetIp);
        if ($failure !== null) {
            $this->mark($domain, ServerCustomDomain::STATUS_FAILED, $failure);

            return ['ok' => false, 'error' => $failure];
        }

        $this->mark($domain, ServerCustomDomain::STATUS_VERIFIED, null, true);

        return ['ok' => true, 'error' => null];
    }

    private function checkOwnership(ServerCustomDomain $domain): ?string
    {
        $name = self::TXT_PREFIX . '.' . $domain->domain;
        // The suppression is the panel's own convention: dns_get_record throws
        // a warning, not an exception, when nothing resolves, so a missing
        // record reads exactly like an unreadable one.
        $records = @dns_get_record($name, DNS_TXT);

        if (!is_array($records) || count($records) === 0) {
            return (string) __('theme.server.domain.error_txt_missing', ['name' => $name]);
        }

        foreach ($records as $record) {
            if (trim((string) ($record['txt'] ?? '')) === $domain->token) {
                return null;
            }
        }

        return (string) __('theme.server.domain.error_txt_mismatch', ['name' => $name]);
    }

    private function checkTarget(string $host, string $targetIp): ?string
    {
        $records = @dns_get_record($host, DNS_A + DNS_AAAA + DNS_CNAME);

        if (!is_array($records) || count($records) === 0) {
            return (string) __('theme.server.domain.error_a_missing', ['host' => $host]);
        }

        foreach ($records as $record) {
            // CNAME aliases resolve through to the target, so an AAAA-only or
            // aliased host reads the same as a direct A record here. Whatever
            // matched, compare the final address text, not the record shape.
            $resolved = trim((string) ($record['ipv6'] ?? $record['ip'] ?? ''));
            if ($resolved !== '' && gethostbyname($host) === $targetIp) {
                return null;
            }
        }

        return (string) __('theme.server.domain.error_a_mismatch', ['host' => $host, 'got' => gethostbyname($host), 'want' => $targetIp]);
    }

    private function mark(ServerCustomDomain $domain, string $status, ?string $error, bool $verified = false): void
    {
        $domain->status = $status;
        $domain->last_error = $error;
        $domain->last_checked_at = now();
        if ($verified) {
            $domain->verified_at = now();
        }
        $domain->save();
    }
}
