<?php

namespace Pterodactyl\Console\Commands\Domain;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Log;
use Pterodactyl\Facades\Activity;
use Pterodactyl\Models\ServerCustomDomain;
use Pterodactyl\Services\Servers\ServerDomainVerificationService;

class RecheckServerDomainsCommand extends Command
{
    protected $signature = 'p:domain:recheck
                            {--limit=200 : Max verified domains to check per run}';

    protected $description = 'Re-check verified custom domains with real DNS lookups and expire any that no longer resolve.';

    public function handle(ServerDomainVerificationService $verifier): int
    {
        $limit = max(1, (int) $this->option('limit'));

        $domains = ServerCustomDomain::query()
            ->where('status', ServerCustomDomain::STATUS_VERIFIED)
            ->with(['server.allocation', 'server.node', 'server.user'])
            ->orderBy('last_checked_at')
            ->limit($limit)
            ->get();

        if ($domains->isEmpty()) {
            $this->line('No verified custom domains to re-check.');

            return self::SUCCESS;
        }

        $checked = 0;
        $kept = 0;
        $expired = 0;

        foreach ($domains as $domain) {
            $server = $domain->server;

            if (is_null($server)) {
                continue;
            }

            try {
                $targetIp = ServerDomainVerificationService::resolveTargetIp($server);

                if (is_null($targetIp)) {
                    continue;
                }

                $result = $verifier->verify($domain, $targetIp);
                $checked++;

                if ($result['ok']) {
                    $kept++;
                } else {
                    // The row already flipped to failed inside the verifier, so
                    // the only job left is telling the owner why: an activity
                    // entry with the server as subject lands in their activity
                    // feed without any extra polling or email plumbing.
                    $expired++;
                    $owner = $server->relationLoaded('user') ? $server->user : $server->user()->first();

                    try {
                        $entry = Activity::event('server:domain.expired')
                            ->subject($server)
                            ->property(['domain' => $domain->domain, 'error' => (string) ($result['error'] ?? '')]);

                        if (!is_null($owner)) {
                            $entry->actor($owner);
                        }

                        $entry->log();
                    } catch (\Throwable $exception) {
                        Log::warning('Domain expiry activity log failed.', [
                            'domain_id' => $domain->id,
                            'server_id' => $domain->server_id,
                            'error' => $exception->getMessage(),
                        ]);
                    }
                }
            } catch (\Throwable $exception) {
                Log::warning('Scheduled domain re-check failed.', [
                    'domain_id' => $domain->id,
                    'server_id' => $domain->server_id,
                    'error' => $exception->getMessage(),
                ]);
            }
        }

        $this->line(sprintf(
            'Domain re-check: %d checked, %d still verified, %d expired.',
            $checked,
            $kept,
            $expired
        ));

        return self::SUCCESS;
    }
}
